(function(g) {
    var window = this;
    var lwa = function(a, b) {
            return g.Jb(a, b)
        },
        Z5 = function(a, b, c) {
            a.A.set(b, c)
        },
        $5 = function(a) {
            Z5(a, "zx", Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ (0, g.B)()).toString(36));
            return a
        },
        a6 = function(a, b, c) {
            Array.isArray(c) || (c = [String(c)]);
            g.bn(a.A, b, c)
        },
        mwa = function(a, b) {
            var c = [];
            g.ik(b, function(d) {
                try {
                    var e = g.ao.prototype.u.call(this, d, !0)
                } catch (f) {
                    if ("Storage: Invalid value was encountered" == f) return;
                    throw f;
                }
                void 0 === e ? c.push(d) : g.$n(e) && c.push(d)
            }, a);
            return c
        },
        nwa = function(a, b) {
            var c = mwa(a, b);
            (0, g.x)(c, function(d) {
                g.ao.prototype.remove.call(this, d)
            }, a)
        },
        owa = function(a) {
            if (a.Wc) {
                if (a.Wc.locationOverrideToken) return {
                    locationOverrideToken: a.Wc.locationOverrideToken
                };
                if (null != a.Wc.latitudeE7 && null != a.Wc.longitudeE7) return {
                    latitudeE7: a.Wc.latitudeE7,
                    longitudeE7: a.Wc.longitudeE7
                }
            }
            return null
        },
        pwa = function(a, b) {
            g.$a(a, b) || a.push(b)
        },
        b6 = function(a) {
            var b = 0,
                c;
            for (c in a) b++;
            return b
        },
        qwa = function(a, b) {
            var c = b instanceof g.tc ? b : g.yc(b, /^data:image\//i.test(b));
            a.src = g.uc(c)
        },
        c6 = function() {},
        rwa = function(a) {
            try {
                return g.v.JSON.parse(a)
            } catch (b) {}
            a = String(a);
            if (/^\s*$/.test(a) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
                return eval("(" + a + ")")
            } catch (b) {}
            throw Error("Invalid JSON string: " + a);
        },
        swa = function(a) {
            if (a.Gd && "function" == typeof a.Gd) return a.Gd();
            if ("string" === typeof a) return a.split("");
            if (g.La(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            return g.Fb(a)
        },
        twa = function(a, b) {
            if (a.forEach && "function" == typeof a.forEach) a.forEach(b, void 0);
            else if (g.La(a) || "string" === typeof a)(0, g.x)(a, b, void 0);
            else {
                if (a.ue && "function" == typeof a.ue) var c = a.ue();
                else if (a.Gd && "function" == typeof a.Gd) c = void 0;
                else if (g.La(a) || "string" === typeof a) {
                    c = [];
                    for (var d = a.length, e = 0; e < d; e++) c.push(e)
                } else c = g.Gb(a);
                d = swa(a);
                e = d.length;
                for (var f = 0; f < e; f++) b.call(void 0, d[f], c && c[f], a)
            }
        },
        uwa = function(a, b, c, d) {
            var e = new g.Qm(null, void 0);
            a && g.Rm(e, a);
            b && g.Sm(e, b);
            c && g.Tm(e, c);
            d && (e.u = d);
            return e
        },
        d6 = function(a, b) {
            g.No[a] = !0;
            var c = g.Lo();
            c && c.publish.apply(c, arguments);
            g.No[a] = !1
        },
        e6 = function(a) {
            this.app = this.name = this.id = "";
            this.type = "REMOTE_CONTROL";
            this.obfuscatedGaiaId = this.avatar = this.username = "";
            this.capabilities = new Set;
            this.experiments = new Set;
            this.theme = "u";
            new g.Nm;
            a && (this.id = a.id || a.name, this.name = a.name, this.app = a.app, this.type = a.type || "REMOTE_CONTROL", this.username = a.user || "", this.avatar = a.userAvatarUri || "", this.obfuscatedGaiaId = a.obfuscatedGaiaId || "", this.theme = a.theme || "u", vwa(this, a.capabilities || ""), wwa(this, a.experiments || ""))
        },
        vwa = function(a, b) {
            a.capabilities.clear();
            (0, g.ue)(b.split(","), g.Qa(lwa, xwa)).forEach(function(c) {
                a.capabilities.add(c)
            })
        },
        wwa = function(a, b) {
            a.experiments.clear();
            b.split(",").forEach(function(c) {
                a.experiments.add(c)
            })
        },
        f6 = function(a) {
            a = a || {};
            this.name = a.name || "";
            this.id = a.id || a.screenId || "";
            this.token = a.token || a.loungeToken || "";
            this.uuid = a.uuid || a.dialId || ""
        },
        g6 = function(a, b) {
            return !!b && (a.id == b || a.uuid == b)
        },
        ywa = function(a) {
            return {
                name: a.name,
                screenId: a.id,
                loungeToken: a.token,
                dialId: a.uuid
            }
        },
        zwa = function(a) {
            return new f6(a)
        },
        Awa = function(a) {
            return Array.isArray(a) ? (0, g.Dc)(a, zwa) : []
        },
        h6 = function(a) {
            return a ? '{name:"' + a.name + '",id:' + a.id.substr(0, 6) + "..,token:" + (a.token ? ".." + a.token.slice(-6) : "-") + ",uuid:" + (a.uuid ? ".." + a.uuid.slice(-6) : "-") + "}" : "null"
        },
        i6 = function(a) {
            return Array.isArray(a) ? "[" + (0, g.Dc)(a, h6).join(",") + "]" : "null"
        },
        j6 = function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
                var b = 16 * Math.random() |
                    0;
                return ("x" == a ? b : b & 3 | 8).toString(16)
            })
        },
        Bwa = function(a) {
            return (0, g.Dc)(a, function(b) {
                return {
                    key: b.id,
                    name: b.name
                }
            })
        },
        k6 = function(a, b) {
            return g.Xa(a, function(c) {
                return c || b ? !c != !b ? !1 : c.id == b.id : !0
            })
        },
        l6 = function(a, b) {
            return g.Xa(a, function(c) {
                return g6(c, b)
            })
        },
        Cwa = function() {
            var a = (0, g.os)();
            a && nwa(a, a.o.eg(!0))
        },
        m6 = function() {
            var a = g.rs("yt-remote-connected-devices") || [];
            g.rb(a);
            return a
        },
        Dwa = function(a) {
            if (g.ab(a)) return [];
            var b = a[0].indexOf("#"),
                c = -1 == b ? a[0] : a[0].substring(0, b);
            return (0, g.Dc)(a, function(d, e) {
                return 0 == e ? d : d.substring(c.length)
            })
        },
        Ewa = function(a) {
            g.qs("yt-remote-connected-devices", a, 86400)
        },
        o6 = function() {
            if (n6) return n6;
            var a = g.rs("yt-remote-device-id");
            a || (a = j6(), g.qs("yt-remote-device-id", a, 31536E3));
            for (var b = m6(), c = 1, d = a; g.$a(b, d);) c++, d = a + "#" + c;
            return n6 = d
        },
        p6 = function() {
            var a = m6(),
                b = o6();
            g.$a(a, b);
            g.us() && g.tb(a, b);
            a = Dwa(a);
            if (g.ab(a)) try {
                g.Cq("remote_sid")
            } catch (c) {} else try {
                g.Aq("remote_sid", a.join(","), -1)
            } catch (c) {}
        },
        Fwa = function() {
            return g.rs("yt-remote-session-browser-channel")
        },
        Gwa = function() {
            return g.rs("yt-remote-local-screens") || []
        },
        Hwa = function() {
            g.qs("yt-remote-lounge-token-expiration", !0, 86400)
        },
        Iwa = function(a) {
            5 < a.length && (a = a.slice(a.length - 5));
            var b = (0, g.Dc)(Gwa(), function(d) {
                    return d.loungeToken
                }),
                c = (0, g.Dc)(a, function(d) {
                    return d.loungeToken
                });
            (0, g.ui)(c, function(d) {
                return !g.$a(b, d)
            }) && Hwa();
            g.qs("yt-remote-local-screens", a, 31536E3)
        },
        Jwa = function(a, b) {
            g.qs("yt-remote-session-browser-channel", a);
            g.qs("yt-remote-session-screen-id", b);
            var c = m6(),
                d = o6();
            g.$a(c, d) || c.push(d);
            Ewa(c);
            p6()
        },
        q6 = function(a) {
            a || (g.ts("yt-remote-session-screen-id"), g.ts("yt-remote-session-video-id"));
            p6();
            a = m6();
            g.db(a, o6());
            Ewa(a)
        },
        Kwa = function() {
            if (!r6) {
                var a = g.lo();
                a && (r6 = new g.Vn(a))
            }
            return r6 ? !!r6.get("yt-remote-use-staging-server") : !1
        },
        Lwa = function(a) {
            return !!document.currentScript && (-1 != document.currentScript.src.indexOf("?" + a) || -1 != document.currentScript.src.indexOf("&" + a))
        },
        Mwa = function() {
            return "function" == typeof window.__onGCastApiAvailable ? window.__onGCastApiAvailable : null
        },
        s6 = function(a) {
            a.length ? Nwa(a.shift(), function() {
                s6(a)
            }) : t6()
        },
        Owa = function(a) {
            return "chrome-extension://" + a + "/cast_sender.js"
        },
        Nwa = function(a, b, c) {
            var d = document.createElement("script");
            d.onerror = b;
            c && (d.onload = c);
            d.src = a;
            (document.head || document.documentElement).appendChild(d)
        },
        t6 = function() {
            var a = Mwa();
            a && a(!1, "No cast extension found")
        },
        Qwa = function() {
            if (Pwa) {
                var a = 2,
                    b = Mwa(),
                    c = function() {
                        a--;
                        0 == a && b && b(!0)
                    };
                window.__onGCastApiAvailable = c;
                Nwa("//www.gstatic.com/cast/sdk/libs/sender/1.0/cast_framework.js", t6, c)
            }
        },
        Rwa = function() {
            Qwa();
            var a = window.navigator.userAgent.match(/Chrome\/([0-9]+)/);
            s6(["//www.gstatic.com/eureka/clank/" + (a ? parseInt(a[1], 10) : 0) + "/cast_sender.js", "//www.gstatic.com/eureka/clank/cast_sender.js"])
        },
        u6 = function(a, b, c) {
            g.z.call(this);
            this.D = null != c ? (0, g.w)(a, c) : a;
            this.Cd = b;
            this.C = (0, g.w)(this.kF, this);
            this.o = !1;
            this.u = 0;
            this.A = this.Ja = null;
            this.B = []
        },
        v6 = function(a, b, c) {
            g.z.call(this);
            this.A = null != c ? (0, g.w)(a, c) : a;
            this.Cd = b;
            this.u = (0, g.w)(this.lF, this);
            this.o = null
        },
        w6 = function(a) {
            a.Ja = g.Uf(a.u, a.Cd);
            var b = a.o;
            a.o = null;
            a.A.apply(null, b)
        },
        x6 = function(a) {
            if (g.v.JSON) try {
                return g.v.JSON.parse(a)
            } catch (b) {}
            return rwa(a)
        },
        y6 = function() {},
        z6 = function() {},
        Swa = function() {},
        Uwa = function(a) {
            return (a = Twa(a)) ? new ActiveXObject(a) : new XMLHttpRequest
        },
        Twa = function(a) {
            if (!a.u && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
                for (var b = ["MSXML2.XMLHTTP.6.0",
                        "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"
                    ], c = 0; c < b.length; c++) {
                    var d = b[c];
                    try {
                        return new ActiveXObject(d), a.u = d
                    } catch (e) {}
                }
                throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
            }
            return a.u
        },
        A6 = function(a, b, c, d) {
            this.o = a;
            this.A = b;
            this.H = c;
            this.G = d || 1;
            this.C = 45E3;
            this.B = new g.A1(this);
            this.u = new g.Tf;
            this.u.setInterval(250)
        },
        Wwa = function(a, b, c) {
            a.Pj = 1;
            a.Yg = $5(b.clone());
            a.ij = c;
            a.D = !0;
            Vwa(a, null)
        },
        B6 = function(a, b, c, d, e) {
            a.Pj = 1;
            a.Yg = $5(b.clone());
            a.ij = null;
            a.D = c;
            e && (a.jC = !1);
            Vwa(a, d)
        },
        Vwa = function(a, b) {
            a.Lk = (0, g.B)();
            C6(a);
            a.Wh = a.Yg.clone();
            a6(a.Wh, "t", a.G);
            a.cn = 0;
            a.Oc = a.o.Ir(a.o.Sm() ? b : null);
            0 < a.Ds && (a.Sp = new v6((0, g.w)(a.eD, a, a.Oc), a.Ds));
            a.B.ma(a.Oc, "readystatechange", a.RN);
            var c = a.Gi ? g.Pb(a.Gi) : {};
            a.ij ? (a.Cq = "POST", c["Content-Type"] = "application/x-www-form-urlencoded", a.Oc.send(a.Wh, a.Cq, a.ij, c)) : (a.Cq = "GET", a.jC && !g.je && (c.Connection = "close"), a.Oc.send(a.Wh, a.Cq, null, c));
            a.o.hf(1)
        },
        Zwa = function(a, b, c) {
            for (var d = !0; !a.oi && a.cn < c.length;) {
                var e = Xwa(a, c);
                if (e == D6) {
                    4 == b && (a.qh = 4, E6(15), d = !1);
                    break
                } else if (e == Ywa) {
                    a.qh = 4;
                    E6(16);
                    d = !1;
                    break
                } else F6(a, e)
            }
            4 == b && 0 == c.length && (a.qh = 1, E6(17), d = !1);
            a.kf = a.kf && d;
            d || (G6(a), H6(a))
        },
        Xwa = function(a, b) {
            var c = a.cn,
                d = b.indexOf("\n", c);
            if (-1 == d) return D6;
            c = Number(b.substring(c, d));
            if (isNaN(c)) return Ywa;
            d += 1;
            if (d + c > b.length) return D6;
            var e = b.substr(d, c);
            a.cn = d + c;
            return e
        },
        axa = function(a, b) {
            a.Lk = (0, g.B)();
            C6(a);
            var c = b ? window.location.hostname : "";
            a.Wh = a.Yg.clone();
            Z5(a.Wh, "DOMAIN", c);
            Z5(a.Wh, "t", a.G);
            try {
                a.qf = new ActiveXObject("htmlfile")
            } catch (n) {
                G6(a);
                a.qh = 7;
                E6(22);
                H6(a);
                return
            }
            var d = "<html><body>";
            if (b) {
                for (var e = "", f = 0; f < c.length; f++) {
                    var k = c.charAt(f);
                    if ("<" == k) e += "\\x3c";
                    else if (">" == k) e += "\\x3e";
                    else {
                        var l = k;
                        if (l in I6) k = I6[l];
                        else if (l in $wa) k = I6[l] = $wa[l];
                        else {
                            var m = l.charCodeAt(0);
                            if (31 < m && 127 > m) k = l;
                            else {
                                if (256 > m) {
                                    if (k = "\\x", 16 > m || 256 < m) k += "0"
                                } else k = "\\u", 4096 > m && (k += "0");
                                k += m.toString(16).toUpperCase()
                            }
                            k =
                                I6[l] = k
                        }
                        e += k
                    }
                }
                d += '<script>document.domain="' + e + '"\x3c/script>'
            }
            c = g.Wc(g.Yb("b/12014412"), d + "</body></html>");
            a.qf.open();
            a.qf.write(g.Rc(c));
            a.qf.close();
            a.qf.parentWindow.m = (0, g.w)(a.nN, a);
            a.qf.parentWindow.d = (0, g.w)(a.rB, a, !0);
            a.qf.parentWindow.rpcClose = (0, g.w)(a.rB, a, !1);
            c = a.qf.createElement("DIV");
            a.qf.parentWindow.document.body.appendChild(c);
            d = g.xc(a.Wh.toString());
            d = g.dd(g.uc(d));
            d = g.Wc(g.Yb("b/12014412"), '<iframe src="' + d + '"></iframe>');
            g.Xc(c, d);
            a.o.hf(1)
        },
        C6 = function(a) {
            a.Av = (0, g.B)() + a.C;
            bxa(a, a.C)
        },
        bxa = function(a, b) {
            if (null != a.Yk) throw Error("WatchDog timer not null");
            a.Yk = J6((0, g.w)(a.vN, a), b)
        },
        K6 = function(a) {
            a.Yk && (g.v.clearTimeout(a.Yk), a.Yk = null)
        },
        H6 = function(a) {
            a.o.by() || a.oi || a.o.ro(a)
        },
        G6 = function(a) {
            K6(a);
            g.He(a.Sp);
            a.Sp = null;
            a.u.stop();
            g.fra(a.B);
            if (a.Oc) {
                var b = a.Oc;
                a.Oc = null;
                b.abort();
                b.dispose()
            }
            a.qf && (a.qf = null)
        },
        F6 = function(a, b) {
            try {
                a.o.jB(a, b), a.o.hf(4)
            } catch (c) {}
        },
        dxa = function(a, b, c, d, e) {
            if (0 == d) c(!1);
            else {
                var f = e || 0;
                d--;
                cxa(a, b, function(k) {
                    k ? c(!0) : g.v.setTimeout(function() {
                        dxa(a, b, c, d, f)
                    }, f)
                })
            }
        },
        cxa = function(a, b, c) {
            var d = new Image;
            d.onload = function() {
                try {
                    L6(d), c(!0)
                } catch (e) {}
            };
            d.onerror = function() {
                try {
                    L6(d), c(!1)
                } catch (e) {}
            };
            d.onabort = function() {
                try {
                    L6(d), c(!1)
                } catch (e) {}
            };
            d.ontimeout = function() {
                try {
                    L6(d), c(!1)
                } catch (e) {}
            };
            g.v.setTimeout(function() {
                if (d.ontimeout) d.ontimeout()
            }, b);
            qwa(d, a)
        },
        L6 = function(a) {
            a.onload = null;
            a.onerror = null;
            a.onabort = null;
            a.ontimeout = null
        },
        exa = function(a) {
            this.o = a;
            this.u = new y6
        },
        fxa = function(a) {
            var b = M6(a.o, a.ql, "/mail/images/cleardot.gif");
            $5(b);
            dxa(b.toString(), 5E3, (0, g.w)(a.jE, a), 3, 2E3);
            a.hf(1)
        },
        O6 = function(a) {
            var b = a.o.J;
            if (null != b) E6(5), b ? (E6(11), N6(a.o, a, !1)) : (E6(12), N6(a.o, a, !0));
            else if (a.Ud = new A6(a, void 0, void 0, void 0), a.Ud.Gi = a.Bs, b = a.o, b = M6(b, b.Sm() ? a.Pl : null, a.Cs), E6(5), !g.he || g.Ld(10)) a6(b, "TYPE", "xmlhttp"), B6(a.Ud, b, !1, a.Pl, !1);
            else {
                a6(b, "TYPE", "html");
                var c = a.Ud;
                a = !!a.Pl;
                c.Pj = 3;
                c.Yg = $5(b.clone());
                axa(c, a)
            }
        },
        P6 = function(a) {
            g.gf.call(this);
            this.headers = new g.Nm;
            this.U = a || null;
            this.A = !1;
            this.S = this.o = null;
            this.ga = this.J = "";
            this.D = 0;
            this.B = "";
            this.C = this.aa = this.H = this.V = !1;
            this.G = 0;
            this.R = null;
            this.ea = "";
            this.N = this.ba = !1
        },
        gxa = function(a) {
            return g.he && g.Kd(9) && "number" === typeof a.timeout && void 0 !== a.ontimeout
        },
        hxa = function(a) {
            return "content-type" == a.toLowerCase()
        },
        jxa = function(a, b) {
            a.A = !1;
            a.o && (a.C = !0, a.o.abort(), a.C = !1);
            a.B = b;
            a.D = 5;
            ixa(a);
            Q6(a)
        },
        ixa = function(a) {
            a.V || (a.V = !0, a.dispatchEvent("complete"), a.dispatchEvent("error"))
        },
        lxa = function(a) {
            if (a.A && "undefined" != typeof g.F1)
                if (a.S[1] && 4 == R6(a) && 2 == a.getStatus()) S6(a, "Local request error detected and ignored");
                else if (a.H && 4 == R6(a)) g.Uf(a.fB, 0, a);
            else if (a.dispatchEvent("readystatechange"), 4 == R6(a)) {
                S6(a, "Request complete");
                a.A = !1;
                try {
                    var b = a.getStatus();
                    a: switch (b) {
                        case 200:
                        case 201:
                        case 202:
                        case 204:
                        case 206:
                        case 304:
                        case 1223:
                            var c = !0;
                            break a;
                        default:
                            c = !1
                    }
                    var d;
                    if (!(d = c)) {
                        var e;
                        if (e = 0 === b) {
                            var f = g.nd(1, String(a.J));
                            if (!f && g.v.self && g.v.self.location) {
                                var k = g.v.self.location.protocol;
                                f = k.substr(0, k.length - 1)
                            }
                            e = !kxa.test(f ? f.toLowerCase() : "")
                        }
                        d = e
                    }
                    if (d) a.dispatchEvent("complete"), a.dispatchEvent("success");
                    else {
                        a.D = 6;
                        try {
                            var l = 2 < R6(a) ? a.o.statusText : ""
                        } catch (m) {
                            l = ""
                        }
                        a.B = l + " [" + a.getStatus() + "]";
                        ixa(a)
                    }
                } finally {
                    Q6(a)
                }
            }
        },
        Q6 = function(a, b) {
            if (a.o) {
                mxa(a);
                var c = a.o,
                    d = a.S[0] ? g.Ia : null;
                a.o = null;
                a.S = null;
                b || a.dispatchEvent("ready");
                try {
                    c.onreadystatechange = d
                } catch (e) {}
            }
        },
        mxa = function(a) {
            a.o && a.N && (a.o.ontimeout = null);
            a.R && (g.v.clearTimeout(a.R), a.R = null)
        },
        R6 = function(a) {
            return a.o ? a.o.readyState : 0
        },
        T6 = function(a) {
            try {
                return a.o ? a.o.responseText : ""
            } catch (b) {
                return ""
            }
        },
        S6 = function(a, b) {
            return b + " [" + a.ga + " " + a.J + " " + a.getStatus() + "]"
        },
        U6 = function(a, b, c) {
            this.o = 1;
            this.u = [];
            this.B = [];
            this.C = new y6;
            this.H = a || null;
            this.J = null != b ? b : null;
            this.D = c || !1
        },
        nxa = function(a, b) {
            this.o = a;
            this.map = b;
            this.context = null
        },
        oxa = function(a) {
            g.Je.call(this, "statevent", a)
        },
        pxa = function(a, b) {
            g.Je.call(this, "timingevent", a);
            this.size = b
        },
        qxa = function(a) {
            g.Je.call(this, "serverreachability", a)
        },
        txa = function(a) {
            rxa(a);
            if (3 == a.o) {
                var b = a.ym++,
                    c = a.ao.clone();
                Z5(c, "SID", a.A);
                Z5(c, "RID", b);
                Z5(c, "TYPE", "terminate");
                V6(a, c);
                b = new A6(a, a.A, b, void 0);
                b.Pj = 2;
                b.Yg = $5(c.clone());
                qwa(new Image, b.Yg.toString());
                b.Lk = (0, g.B)();
                C6(b)
            }
            sxa(a)
        },
        uxa = function(a) {
            a.GE(1, 0);
            a.ao = M6(a, null, a.As);
            W6(a)
        },
        rxa = function(a) {
            a.bh && (a.bh.abort(), a.bh = null);
            a.jc && (a.jc.cancel(), a.jc = null);
            a.fg && (g.v.clearTimeout(a.fg), a.fg = null);
            X6(a);
            a.Nd && (a.Nd.cancel(), a.Nd = null);
            a.ih && (g.v.clearTimeout(a.ih), a.ih = null)
        },
        vxa = function(a, b) {
            if (0 == a.o) throw Error("Invalid operation: sending map when state is closed");
            a.u.push(new nxa(a.JJ++, b));
            2 != a.o && 3 != a.o || W6(a)
        },
        W6 = function(a) {
            a.Nd || a.ih || (a.ih = J6((0, g.w)(a.qB, a), 0), a.Hj = 0)
        },
        xxa = function(a, b) {
            if (1 == a.o) {
                if (!b) {
                    a.ym = Math.floor(1E5 * Math.random());
                    var c = a.ym++,
                        d = new A6(a, "", c, void 0);
                    d.Gi = null;
                    var e = Y6(a),
                        f = a.ao.clone();
                    Z5(f, "RID", c);
                    Z5(f, "CVER", "1");
                    V6(a, f);
                    Wwa(d, f, e);
                    a.Nd = d;
                    a.o = 2
                }
            } else 3 == a.o && (b ? wxa(a, b) : 0 == a.u.length || a.Nd || wxa(a))
        },
        wxa = function(a, b) {
            if (b)
                if (6 < a.ri) {
                    a.u = a.B.concat(a.u);
                    a.B.length = 0;
                    var c = a.ym - 1;
                    var d = Y6(a)
                } else c = b.H, d = b.ij;
            else c = a.ym++, d = Y6(a);
            var e = a.ao.clone();
            Z5(e, "SID", a.A);
            Z5(e, "RID", c);
            Z5(e, "AID", a.dk);
            V6(a, e);
            c = new A6(a, a.A, c, a.Hj + 1);
            c.Gi = null;
            c.setTimeout(1E4 + Math.round(1E4 * Math.random()));
            a.Nd = c;
            Wwa(c, e, d)
        },
        V6 = function(a, b) {
            if (a.yd) {
                var c = a.yd.zx();
                c && g.zb(c, function(d, e) {
                    Z5(b, e, d)
                })
            }
        },
        Y6 = function(a) {
            var b = Math.min(a.u.length, 1E3),
                c = ["count=" + b];
            if (6 < a.ri && 0 < b) {
                var d = a.u[0].o;
                c.push("ofs=" + d)
            } else d = 0;
            for (var e = 0; e < b; e++) {
                var f = a.u[e].o,
                    k = a.u[e].map;
                f = 6 >= a.ri ? e : f - d;
                try {
                    g.zb(k, function(l, m) {
                        c.push("req" + f + "_" + m + "=" + encodeURIComponent(l))
                    })
                } catch (l) {
                    c.push("req" + f + "_type=" + encodeURIComponent("_badmap"))
                }
            }
            a.B = a.B.concat(a.u.splice(0, b));
            return c.join("&")
        },
        yxa = function(a) {
            a.jc || a.fg || (a.G = 1, a.fg = J6((0, g.w)(a.pB, a), 0), a.xj = 0)
        },
        Z6 = function(a) {
            if (a.jc || a.fg || 3 <= a.xj) return !1;
            a.G++;
            a.fg = J6((0, g.w)(a.pB, a), zxa(a, a.xj));
            a.xj++;
            return !0
        },
        N6 = function(a, b, c) {
            a.Aq = c;
            a.Af = b.wg;
            a.D || uxa(a)
        },
        X6 = function(a) {
            null != a.xi && (g.v.clearTimeout(a.xi), a.xi = null)
        },
        zxa = function(a, b) {
            var c = 5E3 + Math.floor(1E4 * Math.random());
            a.isActive() || (c *= 2);
            return c * b
        },
        $6 = function(a, b) {
            if (2 == b || 9 == b) {
                var c = null;
                a.yd && (c = null);
                var d = (0, g.w)(a.BO, a);
                c || (c = new g.Qm("//www.google.com/images/cleardot.gif"), $5(c));
                cxa(c.toString(), 1E4, d)
            } else E6(2);
            Axa(a, b)
        },
        Axa = function(a, b) {
            a.o = 0;
            a.yd && a.yd.Lw(b);
            sxa(a);
            rxa(a)
        },
        sxa = function(a) {
            a.o = 0;
            a.Af = -1;
            if (a.yd)
                if (0 == a.B.length && 0 == a.u.length) a.yd.Ar();
                else {
                    g.gb(a.B);
                    var b = g.gb(a.u);
                    a.B.length = 0;
                    a.u.length = 0;
                    a.yd.Ar(b)
                }
        },
        M6 = function(a, b, c) {
            var d = g.Ym(c);
            if ("" != d.o) b && g.Sm(d, b + "." + d.o), g.Tm(d, d.B);
            else {
                var e = window.location;
                d = uwa(e.protocol, b ? b + "." + e.hostname : e.hostname, +e.port, c)
            }
            a.Fl && g.zb(a.Fl, function(f, k) {
                Z5(d, k, f)
            });
            Z5(d, "VER", a.ri);
            V6(a, d);
            return d
        },
        J6 = function(a, b) {
            if (!g.Ma(a)) throw Error("Fn must not be null and must be a function");
            return g.v.setTimeout(function() {
                a()
            }, b)
        },
        E6 = function(a) {
            a7.dispatchEvent(new oxa(a7, a))
        },
        Bxa = function() {},
        Cxa = function() {
            this.o = [];
            this.u = []
        },
        Dxa = function(a, b) {
            this.action = a;
            this.params = b || {}
        },
        b7 = function(a, b) {
            g.z.call(this);
            this.o = new g.H(this.gN, 0, this);
            g.A(this, this.o);
            this.Cd = 5E3;
            this.u = 0;
            if (g.Ma(a)) b && (a = (0, g.w)(a, b));
            else if (a && g.Ma(a.handleEvent)) a = (0, g.w)(a.handleEvent, a);
            else throw Error("Invalid listener argument");
            this.A = a
        },
        c7 = function(a, b, c) {
            this.R = a;
            this.D = b;
            this.A = new g.Un;
            this.u = new b7(this.eO, this);
            this.o = null;
            this.vb = !1;
            this.C = null;
            this.J = "";
            this.H = this.B = 0;
            this.G = [];
            this.N = c || !1
        },
        Exa = function(a) {
            return {
                firstTestResults: [""],
                secondTestResults: !a.o.Aq,
                sessionId: a.o.A,
                arrayId: a.o.dk
            }
        },
        Fxa = function(a, b) {
            a.H = b || 0;
            a.u.stop();
            a.o && (3 == a.o.o && xxa(a.o), txa(a.o));
            a.H = 0
        },
        d7 = function(a) {
            return !!a.o && 3 == a.o.o
        },
        Gxa = function(a, b) {
            (a.D.loungeIdToken = b) || a.u.stop()
        },
        e7 = function(a) {
            this.port = this.domain = "";
            this.o = "/api/lounge";
            this.u = !0;
            a = a || document.location.href;
            var b = Number(g.nd(4, a)) || "";
            b && (this.port = ":" + b);
            this.domain = g.od(a) || "";
            a = g.Jc;
            0 <= a.search("MSIE") && (a = a.match(/MSIE ([\d.]+)/)[1], 0 > g.qc(a, "10.0") && (this.u = !1))
        },
        f7 = function(a, b) {
            var c = a.o;
            a.u && (c = "https://" + a.domain + a.port + a.o);
            return g.yd(c + b, {})
        },
        g7 = function(a, b, c, d, e) {
            a = {
                format: "JSON",
                method: "POST",
                context: a,
                timeout: 5E3,
                withCredentials: !1,
                onSuccess: g.Qa(a.B, d, !0),
                onError: g.Qa(a.A, e),
                ne: g.Qa(a.C, e)
            };
            c && (a.tb = c, a.headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            });
            return g.tq(b, a)
        },
        Kxa = function() {
            var a = Hxa;
            Ixa();
            h7.push(a);
            Jxa(h7)
        },
        i7 = function(a, b) {
            Ixa();
            var c = h7,
                d = Lxa(a, String(b));
            g.ab(c) ? Mxa(d) : (Jxa(c), (0, g.x)(c, function(e) {
                e(d)
            }))
        },
        Ixa = function() {
            h7 || (h7 = g.Ha("yt.mdx.remote.debug.handlers_") || [], g.Fa("yt.mdx.remote.debug.handlers_", h7, void 0))
        },
        Mxa = function(a) {
            var b = (j7 + 1) % 50;
            j7 = b;
            k7[b] = a;
            l7 || (l7 = 49 == b)
        },
        Jxa = function(a) {
            var b = k7;
            if (b[0]) {
                var c = j7,
                    d = l7 ? c : -1;
                do {
                    d = (d + 1) % 50;
                    var e = b[d];
                    (0, g.x)(a, function(f) {
                        f(e)
                    })
                } while (d != c);
                k7 = Array(50);
                j7 = -1;
                l7 = !1
            }
        },
        Lxa = function(a, b) {
            var c = ((0, g.B)() - Nxa) / 1E3;
            c.toFixed && (c = c.toFixed(3));
            var d = [];
            d.push("[", c + "s", "] ");
            d.push("[", "yt.mdx.remote", "] ");
            d.push(a + ": " + b, "\n");
            return d.join("")
        },
        m7 = function(a) {
            g.N.call(this);
            this.G = a;
            this.o = []
        },
        Oxa = function(a, b) {
            var c = a.get(b.uuid) || a.get(b.id);
            if (c) {
                var d = c.name;
                c.id = b.id || c.id;
                c.name = b.name;
                c.token = b.token;
                c.uuid = b.uuid || c.uuid;
                return c.name != d
            }
            a.o.push(b);
            return !0
        },
        Pxa = function(a, b) {
            var c = a.o.length != b.length;
            a.o = (0, g.ue)(a.o, function(f) {
                return !!k6(b, f)
            });
            for (var d = 0, e = b.length; d < e; d++) c = Oxa(a, b[d]) || c;
            return c
        },
        Qxa = function(a, b) {
            var c = a.o.length;
            a.o = (0, g.ue)(a.o, function(d) {
                return !(d || b ? !d != !b ? 0 : d.id == b.id : 1)
            });
            return a.o.length < c
        },
        n7 = function(a, b, c, d) {
            g.N.call(this);
            this.D = a;
            this.B = b;
            this.C = c;
            this.A = d;
            this.u = 0;
            this.o = null;
            this.Ja = NaN
        },
        p7 = function(a) {
            m7.call(this, "LocalScreenService");
            this.A = a;
            this.u = NaN;
            o7(this);
            this.info("Initializing with " + i6(this.o))
        },
        Rxa = function(a) {
            if (a.o.length) {
                var b = (0, g.Dc)(a.o, function(d) {
                        return d.id
                    }),
                    c = f7(a.A, "/pairing/get_lounge_token_batch");
                g7(a.A, c, {
                    screen_ids: b.join(",")
                }, (0, g.w)(a.vF, a), (0, g.w)(a.uF, a))
            }
        },
        o7 = function(a) {
            var b = Awa(Gwa());
            b = (0, g.ue)(b, function(c) {
                return !c.uuid
            });
            return Pxa(a, b)
        },
        q7 = function(a, b) {
            Iwa((0, g.Dc)(a.o, ywa));
            b && Hwa()
        },
        s7 = function(a, b) {
            g.N.call(this);
            this.D = b;
            var c = g.rs("yt-remote-online-screen-ids") || "";
            c = c ? c.split(",") : [];
            for (var d = {}, e = this.D(), f = 0, k = e.length; f < k; ++f) {
                var l = e[f].id;
                d[l] = g.$a(c, l)
            }
            this.o = d;
            this.C = a;
            this.A = this.B = NaN;
            this.u = null;
            r7("Initialized with " + g.Kk(this.o))
        },
        Sxa = function(a, b, c) {
            var d = f7(a.C, "/pairing/get_screen_availability");
            g7(a.C, d, {
                lounge_token: b.token
            }, (0, g.w)(function(e) {
                e = e.screens || [];
                for (var f = 0, k = e.length; f < k; ++f)
                    if (e[f].loungeToken == b.token) {
                        c("online" == e[f].status);
                        return
                    }
                c(!1)
            }, a), (0, g.w)(function() {
                c(!1)
            }, a))
        },
        t7 = function(a, b) {
            a: if (b6(b) != b6(a.o)) var c = !1;
                else {
                    c = g.Gb(b);
                    for (var d = 0, e = c.length; d < e; ++d)
                        if (!a.o[c[d]]) {
                            c = !1;
                            break a
                        }
                    c = !0
                }c || (r7("Updated online screens: " + g.Kk(a.o)), a.o = b, a.T("screenChange"));Txa(a)
        },
        u7 = function(a) {
            isNaN(a.A) || g.Ko(a.A);
            a.A = g.Io((0, g.w)(a.Ju, a), 0 < a.B && a.B < (0, g.B)() ? 2E4 : 1E4)
        },
        r7 = function(a) {
            i7("OnlineScreenService", a)
        },
        Uxa = function(a) {
            var b = {};
            (0, g.x)(a.D(), function(c) {
                c.token ? b[c.token] = c.id : this.Xb("Requesting availability of screen w/o lounge token.")
            });
            return b
        },
        Txa = function(a) {
            a = g.Gb(g.Ab(a.o, function(b) {
                return b
            }));
            g.rb(a);
            a.length ? g.qs("yt-remote-online-screen-ids", a.join(","), 60) : g.ts("yt-remote-online-screen-ids")
        },
        v7 = function(a) {
            m7.call(this, "ScreenService");
            this.D = a;
            this.u = this.A = null;
            this.B = [];
            this.C = {};
            Vxa(this)
        },
        Xxa = function(a, b, c, d, e, f) {
            a.info("getAutomaticScreenByIds " + c + " / " + b);
            c || (c = a.C[b]);
            var k = a.ge();
            if (k = (c ? l6(k, c) : null) || l6(k, b)) {
                k.uuid = b;
                var l = w7(a, k);
                Sxa(a.u, l, function(m) {
                    e(m ? l : null)
                })
            } else c ? Wxa(a, c, (0, g.w)(function(m) {
                var n = w7(this, new f6({
                    name: d,
                    screenId: c,
                    loungeToken: m,
                    dialId: b || ""
                }));
                Sxa(this.u, n, function(q) {
                    e(q ? n : null)
                })
            }, a), f) : e(null)
        },
        Yxa = function(a, b) {
            for (var c = 0, d = a.o.length; c < d; ++c)
                if (a.o[c].name == b) return a.o[c];
            return null
        },
        Wxa = function(a, b, c, d) {
            a.info("requestLoungeToken_ for " + b);
            var e = {
                tb: {
                    screen_ids: b
                },
                method: "POST",
                context: a,
                onSuccess: function(f, k) {
                    var l = k && k.screens || [];
                    l[0] && l[0].screenId == b ? c(l[0].loungeToken) : d(Error("Missing lounge token in token response"))
                },
                onError: function() {
                    d(Error("Request screen lounge token failed"))
                }
            };
            g.tq(f7(a.D, "/pairing/get_lounge_token_batch"), e)
        },
        Zxa = function(a) {
            a.o = a.A.ge();
            var b = a.C,
                c = {},
                d;
            for (d in b) c[b[d]] = d;
            b = 0;
            for (d = a.o.length; b < d; ++b) {
                var e = a.o[b];
                e.uuid = c[e.id] || ""
            }
            a.info("Updated manual screens: " + i6(a.o))
        },
        Vxa = function(a) {
            x7(a);
            a.A = new p7(a.D);
            a.A.subscribe("screenChange", (0, g.w)(a.DF, a));
            Zxa(a);
            a.B = Awa(g.rs("yt-remote-automatic-screen-cache") || []);
            x7(a);
            a.info("Initializing automatic screens: " + i6(a.B));
            a.u = new s7(a.D, (0, g.w)(a.ge, a, !0));
            a.u.subscribe("screenChange", (0, g.w)(function() {
                this.T("onlineScreenChange")
            }, a))
        },
        w7 = function(a, b) {
            var c = a.get(b.id);
            c ? (c.uuid = b.uuid, b = c) : ((c = l6(a.B, b.uuid)) ? (c.id = b.id, c.token = b.token, b = c) : a.B.push(b), g.qs("yt-remote-automatic-screen-cache", (0, g.Dc)(a.B, ywa)));
            x7(a);
            a.C[b.uuid] = b.id;
            g.qs("yt-remote-device-id-map", a.C, 31536E3);
            return b
        },
        x7 = function(a) {
            a.C = g.rs("yt-remote-device-id-map") || {}
        },
        y7 = function(a, b, c) {
            g.N.call(this);
            this.S = c;
            this.J = a;
            this.u = b;
            this.A = null
        },
        z7 = function(a, b) {
            i7(a.S, b)
        },
        A7 = function(a, b) {
            y7.call(this, a, b, "CastSession");
            this.o = null;
            this.B = 0;
            this.D = (0, g.w)(this.jP, this);
            this.C = (0, g.w)(this.DN, this);
            this.B = g.Io((0, g.w)(function() {
                $xa(this, null)
            }, this), 12E4)
        },
        aya = function(a) {
            a.info("sendYoutubeMessage_: getMdxSessionStatus " + g.Kk(void 0));
            var b = {
                type: "getMdxSessionStatus"
            };
            a.o ? a.o.sendMessage("urn:x-cast:com.google.youtube.mdx", b, g.Ia, (0, g.w)(function() {
                z7(this, "Failed to send message: getMdxSessionStatus.")
            }, a)) : z7(a, "Sending yt message without session: " + g.Kk(b))
        },
        $xa = function(a, b) {
            g.Ko(a.B);
            if (b) {
                if (a.info("onConnectedScreenId_: Received screenId: " + b), !a.A || a.A.id != b) {
                    var c = (0, g.w)(a.Kp, a),
                        d = (0, g.w)(a.me, a);
                    a.Tx(b, c, d, 5)
                }
            } else a.me(Error("Waiting for session status timed out."))
        },
        B7 = function(a, b, c) {
            y7.call(this, a, b, "DialSession");
            this.B = this.H = null;
            this.R = "";
            this.U = c;
            this.C = null;
            this.G = g.Ia;
            this.D = NaN;
            this.N = (0, g.w)(this.mP, this);
            this.o = g.Ia
        },
        bya = function(a) {
            a.o = a.J.kD(a.R, a.u.label, a.u.friendlyName, (0, g.w)(function(b) {
                this.o = g.Ia;
                this.Kp(b)
            }, a), (0, g.w)(function(b) {
                this.o = g.Ia;
                this.me(b)
            }, a))
        },
        cya = function(a) {
            var b = {};
            b.pairingCode = a.R;
            b.theme = a.U;
            if (a.C) {
                var c = a.C.currentTime || 0;
                b.v = a.C.videoId;
                b.t = c
            }
            Kwa() && (b.env_useStageMdx = 1);
            return g.wd(b)
        },
        C7 = function(a, b) {
            y7.call(this, a, b, "ManualSession");
            this.o = g.Io((0, g.w)(this.ek, this, null), 150)
        },
        D7 = function(a, b, c, d) {
            g.N.call(this);
            this.u = a;
            this.G = b || "233637DE";
            this.D = c || "cl";
            this.H = d || !1;
            this.o = null;
            this.C = !1;
            this.A = [];
            this.B = (0, g.w)(this.sM, this)
        },
        dya = function(a, b) {
            return b ? g.Xa(a.A, function(c) {
                return g6(b, c.label)
            }, a) : null
        },
        E7 = function(a) {
            i7("Controller", a)
        },
        Hxa = function(a) {
            window.chrome && chrome.cast && chrome.cast.logMessage && chrome.cast.logMessage(a)
        },
        F7 = function(a) {
            return a.C || !!a.A.length || !!a.o
        },
        G7 = function(a, b, c) {
            b != a.o && (g.He(a.o), (a.o = b) ? (c ? a.T("yt-remote-cast2-receiver-resumed", b.u) : a.T("yt-remote-cast2-receiver-selected",
                b.u), b.subscribe("sessionScreen", (0, g.w)(a.oB, a, b)), b.A ? a.T("yt-remote-cast2-session-change", b.A) : c && a.o.ek(null)) : a.T("yt-remote-cast2-session-change", null))
        },
        eya = function(a) {
            var b = a.u.jD(),
                c = a.o && a.o.u;
            a = (0, g.Dc)(b, function(d) {
                c && g6(d, c.label) && (c = null);
                var e = d.uuid ? d.uuid : d.id,
                    f = dya(this, d);
                f ? (f.label = e, f.friendlyName = d.name) : (f = new chrome.cast.Receiver(e, d.name), f.receiverType = chrome.cast.ReceiverType.CUSTOM);
                return f
            }, a);
            c && (c.receiverType != chrome.cast.ReceiverType.CUSTOM && (c = new chrome.cast.Receiver(c.label, c.friendlyName), c.receiverType = chrome.cast.ReceiverType.CUSTOM), a.push(c));
            return a
        },
        kya = function(a, b, c, d, e, f, k) {
            fya() ? gya(b, e, f, k) && (I7(!0), window.chrome && chrome.cast && chrome.cast.isAvailable ? hya(a, c) : (window.__onGCastApiAvailable = function(l, m) {
                    l ? hya(a, c) : (J7("Failed to load cast API: " + m), K7(!1), I7(!1), g.ts("yt-remote-cast-available"), g.ts("yt-remote-cast-receiver"), iya(), c(!1))
                }, d ? g.Uo("https://www.gstatic.com/cv/js/sender/v1/cast_sender.js") :
                0 <= window.navigator.userAgent.indexOf("Android") && 0 <= window.navigator.userAgent.indexOf("Chrome/") && window.navigator.presentation ? Rwa() : !window.chrome || !window.navigator.presentation || 0 <= window.navigator.userAgent.indexOf("Edge") ? t6() : (Qwa(), s6(jya.map(Owa))))) : H7("Cannot initialize because not running Chrome")
        },
        iya = function() {
            H7("dispose");
            var a = L7();
            a && a.dispose();
            g.Fa("yt.mdx.remote.cloudview.instance_", null, void 0);
            lya(!1);
            g.Qo(M7);
            M7.length = 0
        },
        N7 = function() {
            return !!g.rs("yt-remote-cast-installed")
        },
        mya = function() {
            var a = g.rs("yt-remote-cast-receiver");
            return a ? a.friendlyName : null
        },
        nya = function() {
            H7("clearCurrentReceiver");
            g.ts("yt-remote-cast-receiver")
        },
        oya = function() {
            return N7() ? L7() ? L7().getCastSession() : (J7("getCastSelector: Cast is not initialized."), null) : (J7("getCastSelector: Cast API is not installed!"), null)
        },
        P7 = function() {
            N7() ? L7() ? O7() ? (H7("Requesting cast selector."), L7().requestSession()) : (H7("Wait for cast API to be ready to request the session."), M7.push(g.Po("yt-remote-cast2-api-ready", P7))) : J7("requestCastSelector: Cast is not initialized.") : J7("requestCastSelector: Cast API is not installed!")
        },
        Q7 =
        function(a, b) {
            O7() ? L7().setConnectedScreenStatus(a, b) : J7("setConnectedScreenStatus called before ready.")
        },
        fya = function() {
            var a = 0 <= g.Jc.search(/ (CrMo|Chrome|CriOS)\//);
            return g.qt || a
        },
        pya = function(a, b) {
            L7().init(a, b)
        },
        gya = function(a, b, c, d) {
            var e = !1;
            L7() || (a = new D7(a, b, c, d), a.subscribe("yt-remote-cast2-availability-change", function(f) {
                g.qs("yt-remote-cast-available", f);
                d6("yt-remote-cast2-availability-change", f)
            }), a.subscribe("yt-remote-cast2-receiver-selected", function(f) {
                H7("onReceiverSelected: " + f.friendlyName);
                g.qs("yt-remote-cast-receiver", f);
                d6("yt-remote-cast2-receiver-selected", f)
            }), a.subscribe("yt-remote-cast2-receiver-resumed", function(f) {
                H7("onReceiverResumed: " + f.friendlyName);
                g.qs("yt-remote-cast-receiver", f)
            }), a.subscribe("yt-remote-cast2-session-change", function(f) {
                H7("onSessionChange: " + h6(f));
                f || g.ts("yt-remote-cast-receiver");
                d6("yt-remote-cast2-session-change", f)
            }), g.Fa("yt.mdx.remote.cloudview.instance_", a, void 0), e = !0);
            H7("cloudview.createSingleton_: " + e);
            return e
        },
        L7 = function() {
            return g.Ha("yt.mdx.remote.cloudview.instance_")
        },
        hya = function(a, b) {
            K7(!0);
            I7(!1);
            pya(a, function(c) {
                c ? (lya(!0), g.Ro("yt-remote-cast2-api-ready")) : (J7("Failed to initialize cast API."), K7(!1), g.ts("yt-remote-cast-available"), g.ts("yt-remote-cast-receiver"), iya());
                b(c)
            })
        },
        H7 = function(a) {
            i7("cloudview", a)
        },
        J7 = function(a) {
            i7("cloudview", a)
        },
        K7 = function(a) {
            H7("setCastInstalled_ " + a);
            g.qs("yt-remote-cast-installed", a)
        },
        O7 = function() {
            return !!g.Ha("yt.mdx.remote.cloudview.apiReady_")
        },
        lya = function(a) {
            H7("setApiReady_ " + a);
            g.Fa("yt.mdx.remote.cloudview.apiReady_", a, void 0)
        },
        I7 = function(a) {
            g.Fa("yt.mdx.remote.cloudview.initializing_", a, void 0)
        },
        R7 = function(a) {
            this.index = -1;
            this.videoId = this.listId = "";
            this.volume = this.playerState = -1;
            this.muted = !1;
            this.audioTrackId = null;
            this.D = this.G = 0;
            this.o = null;
            this.hasNext = this.Bf = !1;
            this.J = this.H = this.u = this.C = 0;
            this.B = NaN;
            this.A = !1;
            this.reset(a)
        },
        S7 = function(a) {
            a.audioTrackId = null;
            a.o = null;
            a.playerState = -1;
            a.Bf = !1;
            a.hasNext = !1;
            a.G = 0;
            a.D = (0, g.B)();
            a.C = 0;
            a.u = 0;
            a.H = 0;
            a.J = 0;
            a.B = NaN;
            a.A = !1
        },
        T7 = function(a) {
            return a.fb() ? ((0, g.B)() - a.D) / 1E3 : 0
        },
        U7 = function(a, b) {
            a.G = b;
            a.D = (0, g.B)()
        },
        V7 = function(a) {
            switch (a.playerState) {
                case 1:
                case 1081:
                    return ((0, g.B)() - a.D) / 1E3 + a.G;
                case -1E3:
                    return 0
            }
            return a.G
        },
        W7 = function(a, b, c) {
            var d = a.videoId;
            a.videoId = b;
            a.index = c;
            b != d && S7(a)
        },
        X7 = function(a) {
            var b = {};
            b.index = a.index;
            b.listId = a.listId;
            b.videoId = a.videoId;
            b.playerState = a.playerState;
            b.volume = a.volume;
            b.muted = a.muted;
            b.audioTrackId = a.audioTrackId;
            b.trackData = g.Qb(a.o);
            b.hasPrevious = a.Bf;
            b.hasNext = a.hasNext;
            b.playerTime = a.G;
            b.playerTimeAt = a.D;
            b.seekableStart = a.C;
            b.seekableEnd = a.u;
            b.duration = a.H;
            b.loadedTime = a.J;
            b.liveIngestionTime = a.B;
            return b
        },
        Z7 = function(a, b) {
            g.N.call(this);
            this.o = 0;
            this.B = a;
            this.D = [];
            this.C = new Cxa;
            this.A = this.u = null;
            this.J = (0, g.w)(this.rK, this);
            this.G = (0, g.w)(this.zm, this);
            this.H = (0, g.w)(this.qK, this);
            this.R = (0, g.w)(this.BK, this);
            var c = 0;
            a ? (c = a.getProxyState(), 3 != c && (a.subscribe("proxyStateChange", this.Dv, this), qya(this))) : c = 3;
            0 != c && (b ? this.Dv(c) : g.Io((0, g.w)(function() {
                this.Dv(c)
            }, this), 0));
            var d = oya();
            d && Y7(this, d);
            this.subscribe("yt-remote-cast2-session-change", this.R)
        },
        $7 = function(a) {
            return new R7(a.B.getPlayerContextData())
        },
        qya = function(a) {
            (0, g.x)("nowAutoplaying autoplayDismissed remotePlayerChange remoteQueueChange autoplayModeChange autoplayUpNext previousNextChange".split(" "), function(b) {
                this.D.push(this.B.subscribe(b, g.Qa(this.pM, b), this))
            }, a)
        },
        rya = function(a) {
            (0, g.x)(a.D, function(b) {
                this.B.unsubscribeByKey(b)
            }, a);
            a.D.length = 0
        },
        a8 = function(a, b) {
            var c = a.C;
            50 > c.o.length + c.u.length && a.C.u.push(b)
        },
        c8 = function(a, b, c) {
            var d = $7(a);
            U7(d, c); - 1E3 != d.playerState && (d.playerState = b);
            b8(a, d)
        },
        d8 = function(a, b, c) {
            a.B.sendMessage(b, c)
        },
        b8 = function(a, b) {
            rya(a);
            a.B.setPlayerContextData(X7(b));
            qya(a)
        },
        Y7 = function(a, b) {
            a.A && (a.A.removeUpdateListener(a.J), a.A.removeMediaListener(a.G), a.zm(null));
            a.A = b;
            a.A && (i7("CP", "Setting cast session: " + a.A.sessionId), a.A.addUpdateListener(a.J), a.A.addMediaListener(a.G), a.A.media.length && a.zm(a.A.media[0]))
        },
        sya = function(a) {
            var b = a.u.media,
                c = a.u.customData;
            if (b && c) {
                var d = $7(a);
                b.contentId != d.videoId && i7("CP", "Cast changing video to: " + b.contentId);
                d.videoId = b.contentId;
                d.playerState = c.playerState;
                U7(d, a.u.getEstimatedTime());
                b8(a, d)
            } else i7("CP", "No cast media video. Ignoring state update.")
        },
        e8 = function(a, b, c) {
            return (0, g.w)(function(d) {
                this.Xb("Failed to " + b + " with cast v2 channel. Error code: " + d.code);
                d.code != chrome.cast.ErrorCode.TIMEOUT && (this.Xb("Retrying " + b + " using MDx browser channel."), d8(this, b, c))
            }, a)
        },
        f8 = function(a, b, c) {
            g.N.call(this);
            this.C = NaN;
            this.N = !1;
            this.H = this.G = this.J = this.R = NaN;
            this.S = [];
            this.B = this.D = this.A = this.Xa = this.o = null;
            this.V = a;
            this.S.push(g.ep(window, "beforeunload", (0, g.w)(this.nF, this)));
            this.u = [];
            this.Xa = new R7;
            this.U = b.id;
            this.o = tya(this, c);
            this.o.subscribe("handlerOpened", this.vK, this);
            this.o.subscribe("handlerClosed", this.sK, this);
            this.o.subscribe("handlerError", this.tK, this);
            this.o.subscribe("handlerMessage", this.uK, this);
            Gxa(this.o, b.token);
            this.subscribe("remoteQueueChange", function() {
                var d = this.Xa.videoId;
                g.us() && g.qs("yt-remote-session-video-id", d)
            }, this)
        },
        g8 = function(a) {
            i7("conn", a)
        },
        tya = function(a, b) {
            return new c7(f7(a.V, "/bc"), b)
        },
        h8 = function(a, b) {
            a.T("proxyStateChange", b)
        },
        uya = function(a) {
            a.C = g.Io((0, g.w)(function() {
                g8("Connecting timeout");
                this.Dj(1)
            }, a), 2E4)
        },
        i8 = function(a) {
            g.Ko(a.C);
            a.C = NaN
        },
        j8 = function(a) {
            g.Ko(a.R);
            a.R = NaN
        },
        vya = function(a) {
            k8(a);
            a.J = g.Io((0, g.w)(function() {
                l8(this, "getNowPlaying")
            }, a), 2E4)
        },
        k8 = function(a) {
            g.Ko(a.J);
            a.J = NaN
        },
        xya = function(a, b) {
            b && (i8(a), j8(a));
            b == (d7(a.o) && isNaN(a.C)) ? b && (h8(a, 1), l8(a, "getSubtitlesTrack")) : b ? (a.Rx() && a.Xa.reset(), h8(a, 1), l8(a, "getNowPlaying"), wya(a)) : a.Dj(1)
        },
        yya = function(a, b) {
            var c = b.params.videoId;
            delete b.params.videoId;
            c == a.Xa.videoId && (g.Mb(b.params) ? a.Xa.o = null : a.Xa.o = b.params, a.T("remotePlayerChange"))
        },
        zya = function(a, b) {
            var c = b.params.videoId || b.params.video_id,
                d = parseInt(b.params.currentIndex, 10);
            a.Xa.listId = b.params.listId || a.Xa.listId;
            W7(a.Xa, c, d);
            a.T("remoteQueueChange")
        },
        Bya = function(a, b) {
            b.params = b.params || {};
            zya(a, b);
            Aya(a, b);
            a.T("autoplayDismissed")
        },
        Aya = function(a, b) {
            var c = parseInt(b.params.currentTime || b.params.current_time, 10);
            U7(a.Xa, isNaN(c) ? 0 : c);
            c = parseInt(b.params.state, 10);
            c = isNaN(c) ? -1 : c; - 1 == c && -1E3 == a.Xa.playerState && (c = -1E3);
            a.Xa.playerState = c;
            c = Number(b.params.loadedTime);
            a.Xa.J = isNaN(c) ? 0 : c;
            c = Number(b.params.duration);
            a.Xa.H = isNaN(c) ? 0 : c;
            c = a.Xa;
            var d = Number(b.params.liveIngestionTime);
            c.B = d;
            c.A = isNaN(d) ? !1 : !0;
            c = a.Xa;
            d = Number(b.params.seekableStartTime);
            var e = Number(b.params.seekableEndTime);
            c.C = isNaN(d) ? 0 : d;
            c.u = isNaN(e) ? 0 : e;
            1 == a.Xa.playerState ? vya(a) : k8(a);
            a.T("remotePlayerChange")
        },
        Cya = function(a, b) {
            if (-1E3 !=
                a.Xa.playerState) {
                var c = 1085;
                switch (parseInt(b.params.adState, 10)) {
                    case 1:
                        c = 1081;
                        break;
                    case 2:
                        c = 1084;
                        break;
                    case 0:
                        c = 1083
                }
                a.Xa.playerState = c;
                c = parseInt(b.params.currentTime, 10);
                U7(a.Xa, isNaN(c) ? 0 : c);
                a.T("remotePlayerChange")
            }
        },
        Dya = function(a, b) {
            var c = "true" == b.params.muted;
            a.Xa.volume = parseInt(b.params.volume, 10);
            a.Xa.muted = c;
            a.T("remotePlayerChange")
        },
        Eya = function(a, b) {
            a.D = b.params.videoId;
            a.T("nowAutoplaying", parseInt(b.params.timeout, 10))
        },
        Fya = function(a, b) {
            var c = "true" == b.params.hasNext;
            a.Xa.Bf = "true" == b.params.hasPrevious;
            a.Xa.hasNext = c;
            a.T("previousNextChange")
        },
        wya = function(a) {
            g.Ko(a.H);
            a.H = g.Io((0, g.w)(a.Dj, a, 1), 864E5)
        },
        l8 = function(a, b, c) {
            c ? g8("Sending: action=" + b + ", params=" + g.Kk(c)) : g8("Sending: action=" + b);
            a.o.sendMessage(b, c)
        },
        m8 = function(a) {
            m7.call(this, "ScreenServiceProxy");
            this.Bd = a;
            this.u = [];
            this.u.push(this.Bd.$_s("screenChange", (0, g.w)(this.hP, this)));
            this.u.push(this.Bd.$_s("onlineScreenChange", (0, g.w)(this.TL, this)))
        },
        Kya = function(a) {
            var b = {
                device: "Desktop",
                app: "youtube-desktop"
            };
            b = g.K("MDX_CONFIG") || b;
            Cwa();
            p6();
            n8 || (n8 = new e7(b ? b.loungeApiHost : void 0), Kwa() && (n8.o = "/api/loungedev"));
            o8 || (o8 = g.Ha("yt.mdx.remote.deferredProxies_") || [], g.Fa("yt.mdx.remote.deferredProxies_", o8, void 0));
            Gya();
            var c = p8();
            if (!c) {
                var d = new v7(n8);
                g.Fa("yt.mdx.remote.screenService_", d, void 0);
                c = p8();
                var e = !1,
                    f = void 0,
                    k = void 0,
                    l = !1;
                b && (e = !!b.loadCastApiSetupScript, f = b.appId, k = b.theme, l = !!b.disableDial);
                kya(a, d, function(m) {
                    m ? q8() && Q7(q8(), "YouTube TV") : d.subscribe("onlineScreenChange",
                        function() {
                            d6("yt-remote-receiver-availability-change")
                        })
                }, e, f, k, l)
            }
            b && !g.Ha("yt.mdx.remote.initialized_") && (g.Fa("yt.mdx.remote.initialized_", !0, void 0), r8("Initializing: " + g.Kk(b)), s8.push(g.Po("yt-remote-cast2-availability-change", function() {
                d6("yt-remote-receiver-availability-change")
            })), s8.push(g.Po("yt-remote-cast2-receiver-selected", function() {
                t8(null);
                d6("yt-remote-auto-connect", "cast-selector-receiver")
            })), s8.push(g.Po("yt-remote-cast2-receiver-resumed", function() {
                d6("yt-remote-receiver-resumed", "cast-selector-receiver")
            })), s8.push(g.Po("yt-remote-cast2-session-change", Hya)), s8.push(g.Po("yt-remote-connection-change", function(m) {
                m ? Q7(q8(), "YouTube TV") : u8() || (Q7(null, null), nya())
            })), a = v8(), b.isAuto && (a.id += "#dial"), g.yo("desktop_enable_autoplay") && (a.capabilities = ["atp"]), a.name = b.device, a.app = b.app, (k = b.theme) && (a.theme = k), r8(" -- with channel params: " +
                g.Kk(a)), Iya(a), c.start(), q8() || Jya())
        },
        Mya = function() {
            var a = Lya();
            N7() && g.rs("yt-remote-cast-available") && a.push({
                key: "cast-selector-receiver",
                name: "Cast..."
            });
            return a
        },
        Lya = function() {
            var a = p8().Bd.$_gos();
            var b = w8();
            b && x8() && (k6(a, b) || a.push(b));
            return Bwa(a)
        },
        y8 = function() {
            var a = Nya();
            !a && N7() && mya() && (a = {
                key: "cast-selector-receiver",
                name: mya()
            });
            return a
        },
        Nya = function() {
            var a = Lya(),
                b = w8();
            b || (b = u8());
            return g.Xa(a, function(c) {
                return b && g6(b, c.key) ? !0 : !1
            })
        },
        w8 = function() {
            var a = q8();
            if (!a) return null;
            var b = p8().ge();
            return l6(b, a)
        },
        Hya = function(a) {
            r8("remote.onCastSessionChange_: " + h6(a));
            if (a) {
                var b = w8();
                b && b.id == a.id ? Q7(b.id, "YouTube TV") : (b && z8(), A8(a, 1))
            } else x8() && z8()
        },
        z8 = function() {
            O7() ? L7().stopSession() : J7("stopSession called before API ready.");
            var a = x8();
            a && (a.disconnect(1), B8(null))
        },
        C8 = function() {
            var a = x8();
            return !!a && 3 != a.getProxyState()
        },
        r8 = function(a) {
            i7("remote", a)
        },
        p8 = function() {
            if (!D8) {
                var a = g.Ha("yt.mdx.remote.screenService_");
                D8 = a ? new m8(a) : null
            }
            return D8
        },
        q8 = function() {
            return g.Ha("yt.mdx.remote.currentScreenId_")
        },
        Oya = function(a) {
            g.Fa("yt.mdx.remote.currentScreenId_", a, void 0)
        },
        Pya = function() {
            return g.Ha("yt.mdx.remote.connectData_")
        },
        t8 = function(a) {
            g.Fa("yt.mdx.remote.connectData_", a, void 0)
        },
        x8 = function() {
            return g.Ha("yt.mdx.remote.connection_")
        },
        B8 = function(a) {
            var b = x8();
            t8(null);
            a || Oya("");
            g.Fa("yt.mdx.remote.connection_", a, void 0);
            o8 && ((0, g.x)(o8, function(c) {
                c(a)
            }), o8.length = 0);
            b && !a ? d6("yt-remote-connection-change", !1) : !b && a && d6("yt-remote-connection-change", !0)
        },
        u8 = function() {
            var a = g.us();
            if (!a) return null;
            var b = p8();
            if (!b) return null;
            b = b.ge();
            return l6(b, a)
        },
        A8 = function(a, b) {
            q8();
            w8() && w8();
            if (E8) F8 = a;
            else {
                Oya(a.id);
                var c = new f8(n8, a, v8());
                c.connect(b, Pya());
                c.subscribe("beforeDisconnect", function(d) {
                    d6("yt-remote-before-disconnect", d)
                });
                c.subscribe("beforeDispose", function() {
                    x8() && (x8(), B8(null))
                });
                B8(c)
            }
        },
        Jya = function() {
            var a = u8();
            a ? (r8("Resume connection to: " + h6(a)), A8(a, 0)) : (q6(), nya(), r8("Skipping connecting because no session screen found."))
        },
        Gya = function() {
            var a = v8();
            if (g.Mb(a)) {
                a = o6();
                var b = g.rs("yt-remote-session-name") || "",
                    c = g.rs("yt-remote-session-app") || "";
                a = {
                    device: "REMOTE_CONTROL",
                    id: a,
                    name: b,
                    app: c,
                    mdxVersion: 3
                };
                g.Fa("yt.mdx.remote.channelParams_", a, void 0)
            }
        },
        v8 = function() {
            return g.Ha("yt.mdx.remote.channelParams_") || {}
        },
        Iya = function(a) {
            a ? (g.qs("yt-remote-session-app", a.app), g.qs("yt-remote-session-name", a.name)) : (g.ts("yt-remote-session-app"), g.ts("yt-remote-session-name"));
            g.Fa("yt.mdx.remote.channelParams_", a, void 0)
        },
        G8 = function(a) {
            g.Q.call(this, {
                F: "div",
                I: "ytp-remote",
                L: [{
                    F: "div",
                    I: "ytp-remote-display-status",
                    L: [{
                        F: "div",
                        I: "ytp-remote-display-status-icon",
                        L: [g.FM()]
                    }, {
                        F: "div",
                        I: "ytp-remote-display-status-text",
                        X: "{{statustext}}"
                    }]
                }]
            });
            this.u = new g.jN(this, 250);
            g.A(this, this.u);
            this.A = a;
            this.M(a, "presentingplayerstatechange", this.B);
            Qya(this, g.VK(a))
        },
        Qya = function(a, b) {
            if (3 == a.A.getPresentingPlayerType()) {
                var c = {
                    RECEIVER_NAME: a.A.getOption("remote", "currentReceiver").name
                };
                c = g.U(b, 128) ? g.mM("$RECEIVER_NAME cihaz\u0131nda hata olu\u015ftu", c) : b.fb() || g.U(b, 4) ? g.mM("$RECEIVER_NAME cihaz\u0131nda oynat\u0131l\u0131yor", c) : g.mM("$RECEIVER_NAME cihaz\u0131na ba\u011flan\u0131ld\u0131", c);
                a.na("statustext", c);
                a.u.show()
            } else a.u.hide()
        },
        H8 = function(a, b, c) {
            g.z.call(this);
            var d = this;
            this.module = a;
            this.K = b;
            this.Sa = c;
            this.events = new g.ur(this);
            this.J = this.events.M(this.K, "onVolumeChange", this.OA);
            this.B = !1;
            this.suggestion = null;
            this.C = new g.xC(64);
            this.o = new g.H(this.uC, 500, this);
            this.u = new g.H(this.vC, 1E3, this);
            this.G = new u6(this.KO, 0, this);
            this.A = {};
            this.H = new g.H(this.VC, 1E3, this);
            this.D = new v6(this.seekTo, 1E3, this);
            this.R = g.Ia;
            g.A(this, this.events);
            this.events.M(b, "onCaptionsTrackListChanged", this.qL);
            this.events.M(b, "captionschanged", this.pK);
            this.events.M(b, "captionssettingschanged",
                this.wC);
            this.events.M(b, "videoplayerreset", this.Lp);
            this.events.M(b, "mdxautoplaycancel", function() {
                d.Sa.ex()
            });
            a = this.Sa;
            a.ha();
            a.subscribe("proxyStateChange", this.iB, this);
            a.subscribe("remotePlayerChange", this.Dm, this);
            a.subscribe("remoteQueueChange", this.Lp, this);
            a.subscribe("previousNextChange", this.eB, this);
            a.subscribe("nowAutoplaying", this.aB, this);
            a.subscribe("autoplayDismissed", this.zA, this);
            g.A(this, this.o);
            g.A(this, this.u);
            g.A(this, this.G);
            g.A(this, this.H);
            g.A(this, this.D);
            this.wC();
            this.Lp();
            this.Dm()
        },
        Rya = function(a) {
            a.Rb(0);
            a.o.stop();
            I8(a, new g.xC(64))
        },
        K8 = function(a, b) {
            if (J8(a) && !a.B) {
                var c = null;
                b && (c = {
                    style: a.K.getSubtitlesUserSettings()
                }, g.Sb(c, b));
                a.Sa.hD(a.K.getVideoData(1).videoId, c);
                a.A = $7(a.Sa).o
            }
        },
        L8 = function(a, b) {
            var c = a.K.getPlaylist();
            if (c) {
                var d = c.index;
                var e = c.listId.toString()
            }
            c = a.K.getVideoData(1);
            a.Sa.playVideo(c.videoId, b, d, e, c.playerParams, c.Df, owa(c));
            I8(a, new g.xC(1))
        },
        Sya = function(a, b) {
            if (b) {
                var c = a.K.getOption("captions", "tracklist", {
                    sy: 1
                });
                c && c.length ? (a.K.setOption("captions", "track", b), a.B = !1) : (a.K.loadModule("captions"), a.B = !0)
            } else a.K.setOption("captions", "track", {})
        },
        J8 = function(a) {
            return $7(a.Sa).videoId === a.K.getVideoData(1).videoId
        },
        I8 = function(a, b) {
            a.u.stop();
            var c = a.C;
            if (!g.DC(c, b)) {
                var d = g.U(b, 2);
                d !== g.U(a.C, 2) && g.QS(a.K.app, d);
                a.C = b;
                Tya(a.module, c, b)
            }
        },
        M8 = function() {
            g.Q.call(this, {
                F: "div",
                I: "ytp-mdx-manual-pairing-popup-dialog",
                P: {
                    role: "dialog"
                },
                L: [{
                    F: "div",
                    I: "ytp-mdx-manual-pairing-popup-dialog-inner-content",
                    L: [{
                        F: "div",
                        I: "ytp-mdx-manual-pairing-popup-title",
                        X: "Kod kullanarak web \u00fczerinden TV'nize ba\u011flanma \u00f6zelli\u011fi yak\u0131nda kullan\u0131mdan kald\u0131r\u0131lacak"
                    }, {
                        F: "div",
                        I: "ytp-mdx-manual-pairing-popup-buttons",
                        L: [{
                            F: "button",
                            Z: ["ytp-button", "ytp-mdx-manual-pairing-popup-learn-more"],
                            X: "Daha fazla bilgi edinin"
                        }, {
                            F: "button",
                            Z: ["ytp-button", "ytp-mdx-manual-pairing-popup-ok"],
                            X: "Tamam"
                        }]
                    }]
                }]
            });
            this.u = new g.jN(this, 250);
            this.learnMoreButton = this.o["ytp-mdx-manual-pairing-popup-learn-more"];
            this.okButton = this.o["ytp-mdx-manual-pairing-popup-ok"];
            g.A(this, this.u);
            this.M(this.learnMoreButton, "click", this.A);
            this.M(this.okButton, "click", this.B)
        },
        N8 = function() {
            g.Q.call(this, {
                F: "div",
                I: "ytp-mdx-popup-dialog",
                P: {
                    role: "dialog"
                },
                L: [{
                    F: "div",
                    I: "ytp-mdx-popup-dialog-inner-content",
                    L: [{
                        F: "div",
                        I: "ytp-mdx-popup-title",
                        X: "Oturumunuz kapal\u0131"
                    }, {
                        F: "div",
                        I: "ytp-mdx-popup-description",
                        X: "\u0130zledi\u011finiz videolar TV'nin izleme ge\u00e7mi\u015fine eklenebilir ve TV \u00f6nerilerini etkileyebilir. Bu sorunun \u00f6n\u00fcne ge\u00e7mek i\u00e7in iptal edip bilgisayar \u00fczerinden YouTube'da oturum a\u00e7\u0131n."
                    }, {
                        F: "div",
                        I: "ytp-mdx-privacy-popup-buttons",
                        L: [{
                            F: "button",
                            Z: ["ytp-button",
                                "ytp-mdx-privacy-popup-cancel"
                            ],
                            X: "\u0130ptal"
                        }, {
                            F: "button",
                            Z: ["ytp-button", "ytp-mdx-privacy-popup-confirm"],
                            X: "Onayla"
                        }]
                    }]
                }]
            });
            this.u = new g.jN(this, 250);
            this.cancelButton = this.o["ytp-mdx-privacy-popup-cancel"];
            this.confirmButton = this.o["ytp-mdx-privacy-popup-confirm"];
            g.A(this, this.u);
            this.M(this.cancelButton, "click", this.A);
            this.M(this.confirmButton, "click", this.B)
        },
        O8 = function(a, b) {
            g.PN.call(this, "Oynat\u0131lacak ekran se\u00e7in", 0, a, b);
            this.K = a;
            this.Vh = {};
            this.M(a, "onMdxReceiversChange", this.D);
            this.M(a, "presentingplayerstatechange", this.D);
            this.D()
        },
        P8 = function(a) {
            g.BL.call(this, a);
            this.cf = {
                key: j6(),
                name: "Bu bilgisayar"
            };
            this.ae = null;
            this.subscriptions = [];
            this.vu = this.Sa = null;
            this.Vh = [this.cf];
            this.fh = this.cf;
            this.Cc = new g.xC(64);
            this.Ky = 0;
            this.Uc = -1;
            this.fk = null;
            this.Em = this.So = !1;
            this.hj = this.Gk = null;
            if (!g.Ry(this.player.O())) {
                a = this.player;
                var b = g.VB(a);
                b && (b = b.pm()) && (b = new O8(a, b), g.A(this, b));
                b = new G8(a);
                g.A(this, b);
                g.oL(a, b.element, 4);
                this.Gk = new N8;
                g.A(this, this.Gk);
                g.oL(a, this.Gk.element, 4);
                g.O(this.player.O().experiments, "pair_servlet_deprecation_warning_enabled") &&
                    (this.fk = new M8, g.A(this, this.fk), g.oL(a, this.fk.element, 4));
                this.Em = !!u8();
                this.So = !!g.rs("yt-remote-manual-pairing-warning-shown")
            }
        },
        Q8 = function(a) {
            a.hj && (a.player.removeEventListener("presentingplayerstatechange", a.hj), a.hj = null)
        },
        Tya = function(a, b, c) {
            a.Cc = c;
            a.player.T("presentingplayerstatechange", new g.ZG(c, b))
        },
        Uya = function(a, b, c) {
            var d = !1;
            1 === b ? d = !a.Em : 2 === b && (d = !a.So);
            d && g.aH(c, 8) && (a.player.pauseVideo(), Q8(a))
        },
        R8 = function(a, b) {
            if (b.key !== a.fh.key)
                if (b.key === a.cf.key) z8();
                else {
                    if (a.fk && !a.So && b !== a.cf && "cast-selector-receiver" !== b.key && g.$y(a.player.O())) Vya(a);
                    else {
                        var c;
                        (c = !g.O(a.player.O().experiments, "mdx_enable_privacy_disclosure_ui")) || (c = ((c = g.K("PLAYER_CONFIG")) && c.args && void 0 !== c.args.authuser ? !0 : !(!g.K("SESSION_INDEX") && !g.K("LOGGED_IN"))) || a.Em || !a.Gk);
                        (c ? 0 : g.$y(a.player.O()) || g.dz(a.player.O())) && Wya(a)
                    }
                    a.fh = b;
                    var d = a.player.getPlaylistId();
                    c = a.player.getVideoData(1);
                    var e = c.videoId;
                    if (!d && !e || (2 === a.player.getAppState() || 1 === a.player.getAppState()) &&
                        g.O(a.player.O().experiments, "should_clear_video_data_on_player_cued_unstarted")) c = null;
                    else {
                        var f = a.player.getPlaylist();
                        if (f) {
                            var k = [];
                            for (var l = 0; l < f.getLength(); l++) k[l] = f.Ca(l).videoId
                        } else k = [e];
                        f = a.player.getCurrentTime(1);
                        d = {
                            videoIds: k,
                            listId: d,
                            videoId: e,
                            playerParams: c.playerParams,
                            clickTrackingParams: c.Df,
                            index: Math.max(a.player.getPlaylistIndex(), 0),
                            currentTime: 0 === f ? void 0 : f
                        };
                        (c = owa(c)) && (d.locationInfo = c);
                        c = d
                    }
                    r8("Connecting to: " + g.Kk(b));
                    "cast-selector-receiver" == b.key ? (t8(c || null), c =
                        c || null, O7() ? L7().setLaunchParams(c) : J7("setLaunchParams called before ready.")) : !c && C8() && q8() == b.key ? d6("yt-remote-connection-change", !0) : (z8(), t8(c || null), c = p8().ge(), (c = l6(c, b.key)) && A8(c, 1))
                }
        },
        Wya = function(a) {
            g.VK(a.player).fb() ? a.player.pauseVideo() : (a.hj = function(b) {
                Uya(a, 1, b)
            }, a.player.addEventListener("presentingplayerstatechange", a.hj));
            a.Gk && a.Gk.Tb();
            x8() || (E8 = !0)
        },
        Vya = function(a) {
            g.VK(a.player).fb() ? a.player.pauseVideo() : (a.hj = function(b) {
                Uya(a, 2, b)
            }, a.player.addEventListener("presentingplayerstatechange", a.hj));
            a.fk && a.fk.Tb();
            x8() || (E8 = !0)
        },
        $wa = {
            "\x00": "\\0",
            "\b": "\\b",
            "\f": "\\f",
            "\n": "\\n",
            "\r": "\\r",
            "\t": "\\t",
            "\x0B": "\\x0B",
            '"': '\\"',
            "\\": "\\\\",
            "<": "\\u003C"
        },
        I6 = {
            "'": "\\'"
        },
        Xya = {},
        xwa = {
            KP: "atp",
            xS: "ska",
            iS: "que",
            BR: "mus",
            wS: "sus",
            MQ: "dsp",
            qS: "seq"
        },
        r6, n6 = "",
        Pwa = Lwa("loadCastFramework") || Lwa("loadCastApplicationFramework"),
        jya = ["pkedcjkdefgpdelpbcmbmeomcjbeemfm", "enhhojjnijigcajfphajepfemndkmdlo"];
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    g.Sa(u6, g.z);
    g.h = u6.prototype;
    g.h.jF = function(a) {
        this.B = arguments;
        this.o = !1;
        this.Ja ? this.A = (0, g.B)() + this.Cd : this.Ja = g.Uf(this.C, this.Cd)
    };
    g.h.stop = function() {
        this.Ja && (g.v.clearTimeout(this.Ja), this.Ja = null);
        this.A = null;
        this.o = !1;
        this.B = []
    };
    g.h.pause = function() {
        ++this.u
    };
    g.h.resume = function() {
        this.u && (--this.u, !this.u && this.o && (this.o = !1, this.D.apply(null, this.B)))
    };
    g.h.Y = function() {
        this.stop();
        u6.Gb.Y.call(this)
    };
    g.h.kF = function() {
        this.A ? (this.Ja = g.Uf(this.C, this.A - (0, g.B)()), this.A = null) : (this.Ja = null, this.u ? this.o = !0 : (this.o = !1, this.D.apply(null, this.B)))
    };
    g.Sa(v6, g.z);
    g.h = v6.prototype;
    g.h.Oj = !1;
    g.h.Ol = 0;
    g.h.Ja = null;
    g.h.ay = function(a) {
        this.o = arguments;
        this.Ja || this.Ol ? this.Oj = !0 : w6(this)
    };
    g.h.stop = function() {
        this.Ja && (g.v.clearTimeout(this.Ja), this.Ja = null, this.Oj = !1, this.o = null)
    };
    g.h.pause = function() {
        this.Ol++
    };
    g.h.resume = function() {
        this.Ol--;
        this.Ol || !this.Oj || this.Ja || (this.Oj = !1, w6(this))
    };
    g.h.Y = function() {
        v6.Gb.Y.call(this);
        this.stop()
    };
    g.h.lF = function() {
        this.Ja = null;
        this.Oj && !this.Ol && (this.Oj = !1, w6(this))
    };
    y6.prototype.stringify = function(a) {
        return g.v.JSON.stringify(a, void 0)
    };
    y6.prototype.parse = function(a) {
        return g.v.JSON.parse(a, void 0)
    };
    z6.prototype.o = null;
    z6.prototype.getOptions = function() {
        var a;
        (a = this.o) || (a = {}, Twa(this) && (a[0] = !0, a[1] = !0), a = this.o = a);
        return a
    };
    var S8;
    g.Sa(Swa, z6);
    S8 = new Swa;
    g.h = A6.prototype;
    g.h.Gi = null;
    g.h.kf = !1;
    g.h.Yk = null;
    g.h.Av = null;
    g.h.Lk = null;
    g.h.Pj = null;
    g.h.Yg = null;
    g.h.Wh = null;
    g.h.ij = null;
    g.h.Oc = null;
    g.h.cn = 0;
    g.h.qf = null;
    g.h.Cq = null;
    g.h.qh = null;
    g.h.Ql = -1;
    g.h.jC = !0;
    g.h.oi = !1;
    g.h.Ds = 0;
    g.h.Sp = null;
    var Ywa = {},
        D6 = {};
    g.h = A6.prototype;
    g.h.setTimeout = function(a) {
        this.C = a
    };
    g.h.RN = function(a) {
        a = a.target;
        var b = this.Sp;
        b && 3 == R6(a) ? b.ay() : this.eD(a)
    };
    g.h.eD = function(a) {
        try {
            if (a == this.Oc) a: {
                var b = R6(this.Oc),
                    c = this.Oc.D,
                    d = this.Oc.getStatus();
                if (g.he && !g.Ld(10) || g.je && !g.Kd("420+")) {
                    if (4 > b) break a
                } else if (3 > b || 3 == b && !g.wh && !T6(this.Oc)) break a;this.oi || 4 != b || 7 == c || (8 == c || 0 >= d ? this.o.hf(3) : this.o.hf(2));K6(this);
                var e = this.Oc.getStatus();this.Ql = e;
                var f = T6(this.Oc);
                (this.kf = 200 == e) ? (4 == b && G6(this), this.D ? (Zwa(this, b, f), g.wh && this.kf && 3 == b && (this.B.ma(this.u, "tick", this.KN), this.u.start())) : F6(this, f), this.kf && !this.oi && (4 == b ? this.o.ro(this) : (this.kf = !1, C6(this)))) : (400 == e && 0 < f.indexOf("Unknown SID") ? (this.qh = 3, E6(13)) : (this.qh = 0, E6(14)), G6(this), H6(this))
            }
        } catch (k) {
            this.Oc && T6(this.Oc)
        } finally {}
    };
    g.h.KN = function() {
        var a = R6(this.Oc),
            b = T6(this.Oc);
        this.cn < b.length && (K6(this), Zwa(this, a, b), this.kf && 4 != a && C6(this))
    };
    g.h.nN = function(a) {
        J6((0, g.w)(this.mN, this, a), 0)
    };
    g.h.mN = function(a) {
        this.oi || (K6(this), F6(this, a), C6(this))
    };
    g.h.rB = function(a) {
        J6((0, g.w)(this.lN, this, a), 0)
    };
    g.h.lN = function(a) {
        this.oi || (G6(this), this.kf = a, this.o.ro(this), this.o.hf(4))
    };
    g.h.cancel = function() {
        this.oi = !0;
        G6(this)
    };
    g.h.vN = function() {
        this.Yk = null;
        var a = (0, g.B)();
        0 <= a - this.Av ? (2 != this.Pj && this.o.hf(3), G6(this), this.qh = 2, E6(18), H6(this)) : bxa(this, this.Av - a)
    };
    g.h.getLastError = function() {
        return this.qh
    };
    g.h = exa.prototype;
    g.h.Bs = null;
    g.h.Ud = null;
    g.h.Tp = !1;
    g.h.dy = null;
    g.h.Xn = null;
    g.h.gt = null;
    g.h.Cs = null;
    g.h.ze = null;
    g.h.wg = -1;
    g.h.Pl = null;
    g.h.ql = null;
    g.h.connect = function(a) {
        this.Cs = a;
        a = M6(this.o, null, this.Cs);
        E6(3);
        this.dy = (0, g.B)();
        var b = this.o.H;
        null != b ? (this.Pl = b[0], (this.ql = b[1]) ? (this.ze = 1, fxa(this)) : (this.ze = 2, O6(this))) : (a6(a, "MODE", "init"), this.Ud = new A6(this, void 0, void 0, void 0), this.Ud.Gi = this.Bs, B6(this.Ud, a, !1, null, !0), this.ze = 0)
    };
    g.h.jE = function(a) {
        if (a) this.ze = 2, O6(this);
        else {
            E6(4);
            var b = this.o;
            b.Af = b.bh.wg;
            $6(b, 9)
        }
        a && this.hf(2)
    };
    g.h.Ir = function(a) {
        return this.o.Ir(a)
    };
    g.h.abort = function() {
        this.Ud && (this.Ud.cancel(), this.Ud = null);
        this.wg = -1
    };
    g.h.by = function() {
        return !1
    };
    g.h.jB = function(a, b) {
        this.wg = a.Ql;
        if (0 == this.ze)
            if (b) {
                try {
                    var c = this.u.parse(b)
                } catch (d) {
                    c = this.o;
                    c.Af = this.wg;
                    $6(c, 2);
                    return
                }
                this.Pl = c[0];
                this.ql = c[1]
            } else c = this.o, c.Af = this.wg, $6(c, 2);
        else if (2 == this.ze)
            if (this.Tp) E6(7), this.gt = (0, g.B)();
            else if ("11111" == b) {
            if (E6(6), this.Tp = !0, this.Xn = (0, g.B)(), c = this.Xn - this.dy, !g.he || g.Ld(10) || 500 > c) this.wg = 200, this.Ud.cancel(), E6(12), N6(this.o, this, !0)
        } else E6(8), this.Xn = this.gt = (0, g.B)(), this.Tp = !1
    };
    g.h.ro = function() {
        this.wg = this.Ud.Ql;
        if (this.Ud.kf) 0 == this.ze ? this.ql ? (this.ze = 1, fxa(this)) : (this.ze = 2, O6(this)) : 2 == this.ze && ((!g.he || g.Ld(10) ? !this.Tp : 200 > this.gt - this.Xn) ? (E6(11), N6(this.o, this, !1)) : (E6(12), N6(this.o, this, !0)));
        else {
            0 == this.ze ? E6(9) : 2 == this.ze && E6(10);
            var a = this.o;
            this.Ud.getLastError();
            a.Af = this.wg;
            $6(a, 2)
        }
    };
    g.h.Sm = function() {
        return this.o.Sm()
    };
    g.h.isActive = function() {
        return this.o.isActive()
    };
    g.h.hf = function(a) {
        this.o.hf(a)
    };
    g.Sa(P6, g.gf);
    var kxa = /^https?$/i,
        Yya = ["POST", "PUT"];
    g.h = P6.prototype;
    g.h.send = function(a, b, c, d) {
        if (this.o) throw Error("[goog.net.XhrIo] Object is active with another request=" + this.J + "; newUri=" + a);
        b = b ? b.toUpperCase() : "GET";
        this.J = a;
        this.B = "";
        this.D = 0;
        this.ga = b;
        this.V = !1;
        this.A = !0;
        this.o = this.U ? Uwa(this.U) : Uwa(S8);
        this.S = this.U ? this.U.getOptions() : S8.getOptions();
        this.o.onreadystatechange = (0, g.w)(this.fB, this);
        try {
            c6(S6(this, "Opening Xhr")), this.aa = !0, this.o.open(b, String(a), !0), this.aa = !1
        } catch (f) {
            c6(S6(this, "Error opening Xhr: " + f.message));
            jxa(this, f);
            return
        }
        a =
            c || "";
        var e = this.headers.clone();
        d && twa(d, function(f, k) {
            e.set(k, f)
        });
        d = g.Xa(e.ue(), hxa);
        c = g.v.FormData && a instanceof g.v.FormData;
        !g.$a(Yya, b) || d || c || e.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        e.forEach(function(f, k) {
            this.o.setRequestHeader(k, f)
        }, this);
        this.ea && (this.o.responseType = this.ea);
        "withCredentials" in this.o && this.o.withCredentials !== this.ba && (this.o.withCredentials = this.ba);
        try {
            mxa(this), 0 < this.G && (this.N = gxa(this.o), c6(S6(this, "Will abort after " + this.G + "ms if incomplete, xhr2 " + this.N)), this.N ? (this.o.timeout = this.G, this.o.ontimeout = (0, g.w)(this.ey, this)) : this.R = g.Uf(this.ey, this.G, this)), c6(S6(this, "Sending request")), this.H = !0, this.o.send(a), this.H = !1
        } catch (f) {
            c6(S6(this, "Send error: " + f.message)), jxa(this, f)
        }
    };
    g.h.ey = function() {
        "undefined" != typeof g.F1 && this.o && (this.B = "Timed out after " + this.G + "ms, aborting", this.D = 8, S6(this, this.B), this.dispatchEvent("timeout"), this.abort(8))
    };
    g.h.abort = function(a) {
        this.o && this.A && (S6(this, "Aborting"), this.A = !1, this.C = !0, this.o.abort(), this.C = !1, this.D = a || 7, this.dispatchEvent("complete"), this.dispatchEvent("abort"), Q6(this))
    };
    g.h.Y = function() {
        this.o && (this.A && (this.A = !1, this.C = !0, this.o.abort(), this.C = !1), Q6(this, !0));
        P6.Gb.Y.call(this)
    };
    g.h.fB = function() {
        this.ha() || (this.aa || this.H || this.C ? lxa(this) : this.rM())
    };
    g.h.rM = function() {
        lxa(this)
    };
    g.h.isActive = function() {
        return !!this.o
    };
    g.h.getStatus = function() {
        try {
            return 2 < R6(this) ? this.o.status : -1
        } catch (a) {
            return -1
        }
    };
    g.h.getLastError = function() {
        return "string" === typeof this.B ? this.B : String(this.B)
    };
    g.h = U6.prototype;
    g.h.Fl = null;
    g.h.Nd = null;
    g.h.jc = null;
    g.h.As = null;
    g.h.ao = null;
    g.h.zw = null;
    g.h.qo = null;
    g.h.ym = 0;
    g.h.JJ = 0;
    g.h.yd = null;
    g.h.ih = null;
    g.h.fg = null;
    g.h.xi = null;
    g.h.bh = null;
    g.h.Aq = null;
    g.h.dk = -1;
    g.h.Jy = -1;
    g.h.Af = -1;
    g.h.Hj = 0;
    g.h.xj = 0;
    g.h.ri = 8;
    var a7 = new g.gf;
    g.Sa(oxa, g.Je);
    g.Sa(pxa, g.Je);
    g.Sa(qxa, g.Je);
    g.h = U6.prototype;
    g.h.connect = function(a, b, c, d, e) {
        E6(0);
        this.As = b;
        this.Fl = c || {};
        d && void 0 !== e && (this.Fl.OSID = d, this.Fl.OAID = e);
        this.D ? (J6((0, g.w)(this.Rw, this, a), 100), uxa(this)) : this.Rw(a)
    };
    g.h.Rw = function(a) {
        this.bh = new exa(this);
        this.bh.Bs = null;
        this.bh.u = this.C;
        this.bh.connect(a)
    };
    g.h.by = function() {
        return 0 == this.o
    };
    g.h.qB = function(a) {
        this.ih = null;
        xxa(this, a)
    };
    g.h.pB = function() {
        this.fg = null;
        this.jc = new A6(this, this.A, "rpc", this.G);
        this.jc.Gi = null;
        this.jc.Ds = 0;
        var a = this.zw.clone();
        Z5(a, "RID", "rpc");
        Z5(a, "SID", this.A);
        Z5(a, "CI", this.Aq ? "0" : "1");
        Z5(a, "AID", this.dk);
        V6(this, a);
        if (!g.he || g.Ld(10)) Z5(a, "TYPE", "xmlhttp"), B6(this.jc, a, !0, this.qo, !1);
        else {
            Z5(a, "TYPE", "html");
            var b = this.jc,
                c = !!this.qo;
            b.Pj = 3;
            b.Yg = $5(a.clone());
            axa(b, c)
        }
    };
    g.h.jB = function(a, b) {
        if (0 != this.o && (this.jc == a || this.Nd == a))
            if (this.Af = a.Ql, this.Nd == a && 3 == this.o)
                if (7 < this.ri) {
                    try {
                        var c = this.C.parse(b)
                    } catch (f) {
                        c = null
                    }
                    if (Array.isArray(c) && 3 == c.length)
                        if (0 == c[0]) a: {
                            if (!this.fg) {
                                if (this.jc)
                                    if (this.jc.Lk + 3E3 < this.Nd.Lk) X6(this), this.jc.cancel(), this.jc = null;
                                    else break a;
                                Z6(this);
                                E6(19)
                            }
                        }
                    else this.Jy = c[1], 0 < this.Jy - this.dk && 37500 > c[2] && this.Aq && 0 == this.xj && !this.xi && (this.xi = J6((0, g.w)(this.lK, this), 6E3));
                    else $6(this, 11)
                } else b != Xya.hQ.o && $6(this, 11);
        else if (this.jc ==
            a && X6(this), !g.fc(b)) {
            c = this.C.parse(b);
            for (var d = 0; d < c.length; d++) {
                var e = c[d];
                this.dk = e[0];
                e = e[1];
                2 == this.o ? "c" == e[0] ? (this.A = e[1], this.qo = e[2], e = e[3], null != e ? this.ri = e : this.ri = 6, this.o = 3, this.yd && this.yd.Nw(), this.zw = M6(this, this.Sm() ? this.qo : null, this.As), yxa(this)) : "stop" == e[0] && $6(this, 7) : 3 == this.o && ("stop" == e[0] ? $6(this, 7) : "noop" != e[0] && this.yd && this.yd.Mw(e), this.xj = 0)
            }
        }
    };
    g.h.lK = function() {
        null != this.xi && (this.xi = null, this.jc.cancel(), this.jc = null, Z6(this), E6(20))
    };
    g.h.ro = function(a) {
        if (this.jc == a) {
            X6(this);
            this.jc = null;
            var b = 2
        } else if (this.Nd == a) this.Nd = null, b = 1;
        else return;
        this.Af = a.Ql;
        if (0 != this.o)
            if (a.kf) 1 == b ? (b = (0, g.B)() - a.Lk, a7.dispatchEvent(new pxa(a7, a.ij ? a.ij.length : 0, b, this.Hj)), W6(this), this.B.length = 0) : yxa(this);
            else {
                var c = a.getLastError(),
                    d;
                if (!(d = 3 == c || 7 == c || 0 == c && 0 < this.Af)) {
                    if (d = 1 == b) this.Nd || this.ih || 1 == this.o || 2 <= this.Hj ? d = !1 : (this.ih = J6((0, g.w)(this.qB, this, a), zxa(this, this.Hj)), this.Hj++, d = !0);
                    d = !(d || 2 == b && Z6(this))
                }
                if (d) switch (c) {
                    case 1:
                        $6(this,
                            5);
                        break;
                    case 4:
                        $6(this, 10);
                        break;
                    case 3:
                        $6(this, 6);
                        break;
                    case 7:
                        $6(this, 12);
                        break;
                    default:
                        $6(this, 2)
                }
            }
    };
    g.h.GE = function(a) {
        if (!g.$a(arguments, this.o)) throw Error("Unexpected channel state: " + this.o);
    };
    g.h.BO = function(a) {
        a ? E6(2) : (E6(1), Axa(this, 8))
    };
    g.h.Ir = function(a) {
        if (a) throw Error("Can't create secondary domain capable XhrIo object.");
        a = new P6;
        a.ba = !1;
        return a
    };
    g.h.isActive = function() {
        return !!this.yd && this.yd.isActive(this)
    };
    g.h.hf = function(a) {
        a7.dispatchEvent(new qxa(a7, a))
    };
    g.h.Sm = function() {
        return !(!g.he || g.Ld(10))
    };
    g.h = Bxa.prototype;
    g.h.Nw = function() {};
    g.h.Mw = function() {};
    g.h.Lw = function() {};
    g.h.Ar = function() {};
    g.h.zx = function() {
        return {}
    };
    g.h.isActive = function() {
        return !0
    };
    g.h = Cxa.prototype;
    g.h.isEmpty = function() {
        return g.ab(this.o) && g.ab(this.u)
    };
    g.h.clear = function() {
        this.o = [];
        this.u = []
    };
    g.h.contains = function(a) {
        return g.$a(this.o, a) || g.$a(this.u, a)
    };
    g.h.remove = function(a) {
        var b = this.o;
        var c = (0, g.kra)(b, a);
        0 <= c ? (g.cb(b, c), b = !0) : b = !1;
        return b || g.db(this.u, a)
    };
    g.h.Gd = function() {
        for (var a = [], b = this.o.length - 1; 0 <= b; --b) a.push(this.o[b]);
        var c = this.u.length;
        for (b = 0; b < c; ++b) a.push(this.u[b]);
        return a
    };
    g.Sa(b7, g.z);
    g.h = b7.prototype;
    g.h.gN = function() {
        this.Cd = Math.min(3E5, 2 * this.Cd);
        this.A();
        this.u && this.start()
    };
    g.h.start = function() {
        var a = this.Cd + 15E3 * Math.random();
        this.o.Wa(a);
        this.u = (0, g.B)() + a
    };
    g.h.stop = function() {
        this.o.stop();
        this.u = 0
    };
    g.h.isActive = function() {
        return this.o.isActive()
    };
    g.h.reset = function() {
        this.o.stop();
        this.Cd = 5E3
    };
    g.Sa(c7, Bxa);
    g.h = c7.prototype;
    g.h.subscribe = function(a, b, c) {
        return this.A.subscribe(a, b, c)
    };
    g.h.unsubscribe = function(a, b, c) {
        return this.A.unsubscribe(a, b, c)
    };
    g.h.Mh = function(a) {
        return this.A.Hi(a)
    };
    g.h.T = function(a, b) {
        return this.A.T.apply(this.A, arguments)
    };
    g.h.dispose = function() {
        this.vb || (this.vb = !0, g.He(this.A), Fxa(this), g.He(this.u), this.u = null)
    };
    g.h.ha = function() {
        return this.vb
    };
    g.h.connect = function(a, b, c) {
        if (!this.o || 2 != this.o.o) {
            this.J = "";
            this.u.stop();
            this.C = a || null;
            this.B = b || 0;
            a = this.R + "/test";
            b = this.R + "/bind";
            var d = new U6(c ? c.firstTestResults : null, c ? c.secondTestResults : null, this.N),
                e = this.o;
            e && (e.yd = null);
            d.yd = this;
            this.o = d;
            e ? this.o.connect(a, b, this.D, e.A, e.dk) : c ? this.o.connect(a, b, this.D, c.sessionId, c.arrayId) : this.o.connect(a, b, this.D)
        }
    };
    g.h.sendMessage = function(a, b) {
        var c = {
            _sc: a
        };
        b && g.Sb(c, b);
        this.u.isActive() || 2 == (this.o ? this.o.o : 0) ? this.G.push(c) : d7(this) && vxa(this.o, c)
    };
    g.h.Nw = function() {
        this.u.reset();
        this.C = null;
        this.B = 0;
        if (this.G.length) {
            var a = this.G;
            this.G = [];
            for (var b = 0, c = a.length; b < c; ++b) vxa(this.o, a[b])
        }
        this.T("handlerOpened")
    };
    g.h.Lw = function(a) {
        var b = 2 == a && 401 == this.o.Af;
        4 == a || b || this.u.start();
        this.T("handlerError", a)
    };
    g.h.Ar = function(a) {
        if (!this.u.isActive()) this.T("handlerClosed");
        else if (a)
            for (var b = 0, c = a.length; b < c; ++b) {
                var d = a[b].map;
                d && this.G.push(d)
            }
    };
    g.h.zx = function() {
        var a = {
            v: 2
        };
        this.J && (a.gsessionid = this.J);
        0 != this.B && (a.ui = "" + this.B);
        0 != this.H && (a.ui = "" + this.H);
        this.C && g.Sb(a, this.C);
        return a
    };
    g.h.Mw = function(a) {
        "S" == a[0] ? this.J = a[1] : "gracefulReconnect" == a[0] ? (this.u.start(), txa(this.o)) : this.T("handlerMessage", new Dxa(a[0], a[1]))
    };
    g.h.eO = function() {
        this.u.isActive();
        var a = this.o,
            b = 0;
        a.jc && b++;
        a.Nd && b++;
        0 == b && this.connect(this.C, this.B)
    };
    e7.prototype.B = function(a, b, c, d) {
        b ? a(d) : a({
            text: c.responseText
        })
    };
    e7.prototype.A = function(a, b) {
        a(Error("Request error: " + b.status))
    };
    e7.prototype.C = function(a) {
        a(Error("request timed out"))
    };
    var Nxa = (0, g.B)(),
        h7 = null,
        k7 = Array(50),
        j7 = -1,
        l7 = !1;
    g.Sa(m7, g.N);
    m7.prototype.ge = function() {
        return this.o
    };
    m7.prototype.contains = function(a) {
        return !!k6(this.o, a)
    };
    m7.prototype.get = function(a) {
        return a ? l6(this.o, a) : null
    };
    m7.prototype.info = function(a) {
        i7(this.G, a)
    };
    g.r(n7, g.N);
    g.h = n7.prototype;
    g.h.start = function() {
        !this.o && isNaN(this.Ja) && this.iD()
    };
    g.h.stop = function() {
        this.o && (this.o.abort(), this.o = null);
        isNaN(this.Ja) || (g.Ko(this.Ja), this.Ja = NaN)
    };
    g.h.Y = function() {
        this.stop();
        g.N.prototype.Y.call(this)
    };
    g.h.iD = function() {
        this.Ja = NaN;
        this.o = g.tq(f7(this.D, "/pairing/get_screen"), {
            method: "POST",
            tb: {
                pairing_code: this.B
            },
            timeout: 5E3,
            onSuccess: (0, g.w)(this.fP, this),
            onError: (0, g.w)(this.eP, this),
            ne: (0, g.w)(this.gP, this)
        })
    };
    g.h.fP = function(a, b) {
        this.o = null;
        var c = b.screen || {};
        c.dialId = this.C;
        c.name = this.A;
        this.T("pairingComplete", new f6(c))
    };
    g.h.eP = function(a) {
        this.o = null;
        a.status && 404 == a.status ? this.u >= Zya.length ? this.T("pairingFailed", Error("DIAL polling timed out")) : (a = Zya[this.u], this.Ja = g.Io((0, g.w)(this.iD, this), a), this.u++) : this.T("pairingFailed", Error("Server error " + a.status))
    };
    g.h.gP = function() {
        this.o = null;
        this.T("pairingFailed", Error("Server not responding"))
    };
    var Zya = [2E3, 2E3, 1E3, 1E3, 1E3, 2E3, 2E3, 5E3, 5E3, 1E4];
    g.Sa(p7, m7);
    g.h = p7.prototype;
    g.h.start = function() {
        o7(this) && this.T("screenChange");
        !g.rs("yt-remote-lounge-token-expiration") && Rxa(this);
        g.Ko(this.u);
        this.u = g.Io((0, g.w)(this.start, this), 1E4)
    };
    g.h.add = function(a, b) {
        o7(this);
        Oxa(this, a);
        q7(this, !1);
        this.T("screenChange");
        b(a);
        a.token || Rxa(this)
    };
    g.h.remove = function(a, b) {
        var c = o7(this);
        Qxa(this, a) && (q7(this, !1), c = !0);
        b(a);
        c && this.T("screenChange")
    };
    g.h.yq = function(a, b, c, d) {
        var e = o7(this),
            f = this.get(a.id);
        f ? (f.name != b && (f.name = b, q7(this, !1), e = !0), c(a)) : d(Error("no such local screen."));
        e && this.T("screenChange")
    };
    g.h.Y = function() {
        g.Ko(this.u);
        p7.Gb.Y.call(this)
    };
    g.h.vF = function(a) {
        o7(this);
        var b = this.o.length;
        a = a && a.screens || [];
        for (var c = 0, d = a.length; c < d; ++c) {
            var e = a[c],
                f = this.get(e.screenId);
            f && (f.token = e.loungeToken, --b)
        }
        q7(this, !b);
        b && i7(this.G, "Missed " + b + " lounge tokens.")
    };
    g.h.uF = function(a) {
        i7(this.G, "Requesting lounge tokens failed: " + a)
    };
    g.r(s7, g.N);
    g.h = s7.prototype;
    g.h.start = function() {
        var a = parseInt(g.rs("yt-remote-fast-check-period") || "0", 10);
        (this.B = (0, g.B)() - 144E5 < a ? 0 : a) ? u7(this): (this.B = (0, g.B)() + 3E5, g.qs("yt-remote-fast-check-period", this.B), this.Ju())
    };
    g.h.isEmpty = function() {
        return g.Mb(this.o)
    };
    g.h.update = function() {
        r7("Updating availability on schedule.");
        var a = this.D(),
            b = g.Ab(this.o, function(c, d) {
                return c && !!l6(a, d)
            }, this);
        t7(this, b)
    };
    g.h.Y = function() {
        g.Ko(this.A);
        this.A = NaN;
        this.u && (this.u.abort(), this.u = null);
        g.N.prototype.Y.call(this)
    };
    g.h.Ju = function() {
        g.Ko(this.A);
        this.A = NaN;
        this.u && this.u.abort();
        var a = Uxa(this);
        if (b6(a)) {
            var b = f7(this.C, "/pairing/get_screen_availability");
            this.u = g7(this.C, b, {
                lounge_token: g.Gb(a).join(",")
            }, (0, g.w)(this.QM, this, a), (0, g.w)(this.PM, this))
        } else t7(this, {}), u7(this)
    };
    g.h.QM = function(a, b) {
        this.u = null;
        var c = g.Gb(Uxa(this));
        if (g.sb(c, g.Gb(a))) {
            c = b.screens || [];
            for (var d = {}, e = 0, f = c.length; e < f; ++e) d[a[c[e].loungeToken]] = "online" == c[e].status;
            t7(this, d);
            u7(this)
        } else this.Xb("Changing Screen set during request."), this.Ju()
    };
    g.h.PM = function(a) {
        this.Xb("Screen availability failed: " + a);
        this.u = null;
        u7(this)
    };
    g.h.Xb = function(a) {
        i7("OnlineScreenService", a)
    };
    g.Sa(v7, m7);
    g.h = v7.prototype;
    g.h.start = function() {
        this.A.start();
        this.u.start();
        this.o.length && (this.T("screenChange"), this.u.isEmpty() || this.T("onlineScreenChange"))
    };
    g.h.add = function(a, b, c) {
        this.A.add(a, b, c)
    };
    g.h.remove = function(a, b, c) {
        this.A.remove(a, b, c);
        this.u.update()
    };
    g.h.yq = function(a, b, c, d) {
        this.A.contains(a) ? this.A.yq(a, b, c, d) : (a = "Updating name of unknown screen: " + a.name, i7(this.G, a), d(Error(a)))
    };
    g.h.ge = function(a) {
        return a ? this.o : g.fb(this.o, (0, g.ue)(this.B, function(b) {
            return !this.contains(b)
        }, this))
    };
    g.h.jD = function() {
        return (0, g.ue)(this.ge(!0), function(a) {
            return !!this.u.o[a.id]
        }, this)
    };
    g.h.kD = function(a, b, c, d, e) {
        this.info("getDialScreenByPairingCode " + a + " / " + b);
        var f = new n7(this.D, a, b, c);
        f.subscribe("pairingComplete", (0, g.w)(function(k) {
            g.He(f);
            d(w7(this, k))
        }, this));
        f.subscribe("pairingFailed", function(k) {
            g.He(f);
            e(k)
        });
        f.start();
        return (0, g.w)(f.stop, f)
    };
    g.h.iP = function(a, b, c, d) {
        g.tq(f7(this.D, "/pairing/get_screen"), {
            method: "POST",
            tb: {
                pairing_code: a
            },
            timeout: 5E3,
            onSuccess: (0, g.w)(function(e, f) {
                var k = new f6(f.screen || {});
                if (!k.name || Yxa(this, k.name)) {
                    a: {
                        var l = k.name;
                        for (var m = 2, n = b(l, m); Yxa(this, n);) {
                            m++;
                            if (20 < m) break a;
                            n = b(l, m)
                        }
                        l = n
                    }
                    k.name = l
                }
                c(w7(this, k))
            }, this),
            onError: (0, g.w)(function(e) {
                d(Error("pairing request failed: " + e.status))
            }, this),
            ne: (0, g.w)(function() {
                d(Error("pairing request timed out."))
            }, this)
        })
    };
    g.h.Y = function() {
        g.He(this.A);
        g.He(this.u);
        v7.Gb.Y.call(this)
    };
    g.h.DF = function() {
        Zxa(this);
        this.T("screenChange");
        this.u.update()
    };
    v7.prototype.dispose = v7.prototype.dispose;
    g.Sa(y7, g.N);
    g.h = y7.prototype;
    g.h.Kp = function(a) {
        this.A = a;
        this.T("sessionScreen", this.A)
    };
    g.h.me = function(a) {
        this.ha() || (a && z7(this, "" + a), this.A = null, this.T("sessionScreen", null))
    };
    g.h.info = function(a) {
        i7(this.S, a)
    };
    g.h.mD = function() {
        return null
    };
    g.h.Su = function(a) {
        var b = this.u;
        a ? (b.displayStatus = new chrome.cast.ReceiverDisplayStatus(a, []), b.displayStatus.showStop = !0) : b.displayStatus = null;
        chrome.cast.setReceiverDisplayStatus(b, (0, g.w)(function() {
            this.info("Updated receiver status for " + b.friendlyName + ": " + a)
        }, this), (0, g.w)(function() {
            z7(this, "Failed to update receiver status for: " + b.friendlyName)
        }, this))
    };
    g.h.Y = function() {
        this.Su("");
        y7.Gb.Y.call(this)
    };
    g.Sa(A7, y7);
    g.h = A7.prototype;
    g.h.Ru = function(a) {
        if (this.o) {
            if (this.o == a) return;
            z7(this, "Overriding cast sesison with new session object");
            this.o.removeUpdateListener(this.D);
            this.o.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.C)
        }
        this.o = a;
        this.o.addUpdateListener(this.D);
        this.o.addMessageListener("urn:x-cast:com.google.youtube.mdx", this.C);
        aya(this)
    };
    g.h.ek = function(a) {
        this.info("launchWithParams no-op for Cast: " + g.Kk(a))
    };
    g.h.stop = function() {
        this.o ? this.o.stop((0, g.w)(function() {
            this.me()
        }, this), (0, g.w)(function() {
            this.me(Error("Failed to stop receiver app."))
        }, this)) : this.me(Error("Stopping cast device witout session."))
    };
    g.h.Su = g.Ia;
    g.h.Y = function() {
        this.info("disposeInternal");
        g.Ko(this.B);
        this.B = 0;
        this.o && (this.o.removeUpdateListener(this.D), this.o.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.C));
        this.o = null;
        A7.Gb.Y.call(this)
    };
    g.h.DN = function(a, b) {
        if (!this.ha())
            if (b) {
                var c = x6(b);
                if (g.Na(c)) {
                    var d = "" + c.type;
                    c = c.data || {};
                    this.info("onYoutubeMessage_: " + d + " " + g.Kk(c));
                    switch (d) {
                        case "mdxSessionStatus":
                            $xa(this, c.screenId);
                            break;
                        default:
                            z7(this, "Unknown youtube message: " + d)
                    }
                } else z7(this, "Unable to parse message.")
            } else z7(this, "No data in message.")
    };
    g.h.Tx = function(a, b, c, d) {
        Xxa(this.J, this.u.label, a, this.u.friendlyName, (0, g.w)(function(e) {
            e ? b(e) : 0 <= d ? (z7(this, "Screen " + a + " appears to be offline. " + d + " retries left."), g.Io((0, g.w)(this.Tx, this, a, b, c, d - 1), 300)) : c(Error("Unable to fetch screen."))
        }, this), c)
    };
    g.h.mD = function() {
        return this.o
    };
    g.h.jP = function(a) {
        this.ha() || a || (z7(this, "Cast session died."), this.me())
    };
    g.Sa(B7, y7);
    g.h = B7.prototype;
    g.h.Ru = function(a) {
        this.B = a;
        this.B.addUpdateListener(this.N)
    };
    g.h.ek = function(a) {
        this.C = a;
        this.G()
    };
    g.h.stop = function() {
        this.o();
        this.o = g.Ia;
        g.Ko(this.D);
        this.B ? this.B.stop((0, g.w)(this.me, this, null), (0, g.w)(this.me, this, "Failed to stop DIAL device.")) : this.me()
    };
    g.h.Y = function() {
        this.o();
        this.o = g.Ia;
        g.Ko(this.D);
        this.B && this.B.removeUpdateListener(this.N);
        this.B = null;
        B7.Gb.Y.call(this)
    };
    g.h.mP = function(a) {
        this.ha() || a || (z7(this, "DIAL session died."), this.o(), this.o = g.Ia, this.me())
    };
    g.h.Ns = function(a) {
        this.R = j6();
        if (this.C) {
            var b = new chrome.cast.DialLaunchResponse(!0, cya(this));
            a(b);
            bya(this)
        } else this.G = (0, g.w)(function() {
            g.Ko(this.D);
            this.G = g.Ia;
            this.D = NaN;
            var c = new chrome.cast.DialLaunchResponse(!0, cya(this));
            a(c);
            bya(this)
        }, this), this.D = g.Io((0, g.w)(function() {
            this.G()
        }, this), 100)
    };
    g.h.XF = function(a, b, c) {
        Xxa(this.J, this.H.receiver.label, a, this.u.friendlyName, (0, g.w)(function(d) {
            d && d.token ? (this.Kp(d), b(new chrome.cast.DialLaunchResponse(!1))) : this.Ns(b, c)
        }, this), (0, g.w)(function(d) {
            z7(this, "Failed to get DIAL screen: " + d);
            this.Ns(b, c)
        }, this))
    };
    g.Sa(C7, y7);
    C7.prototype.stop = function() {
        this.me()
    };
    C7.prototype.Ru = g.Ia;
    C7.prototype.ek = function() {
        g.Ko(this.o);
        this.o = NaN;
        var a = l6(this.J.ge(), this.u.label);
        a ? this.Kp(a) : this.me(Error("No such screen"))
    };
    C7.prototype.Y = function() {
        g.Ko(this.o);
        this.o = NaN;
        C7.Gb.Y.call(this)
    };
    g.Sa(D7, g.N);
    g.h = D7.prototype;
    g.h.init = function(a, b) {
        chrome.cast.timeout.requestSession = 3E4;
        var c = new chrome.cast.SessionRequest(this.G);
        this.H || (c.dialRequest = new chrome.cast.DialRequest("YouTube"));
        var d = chrome.cast.AutoJoinPolicy.TAB_AND_ORIGIN_SCOPED,
            e = a ? chrome.cast.DefaultActionPolicy.CAST_THIS_TAB : chrome.cast.DefaultActionPolicy.CREATE_SESSION,
            f = (0, g.w)(this.wM, this);
        c = new chrome.cast.ApiConfig(c, (0, g.w)(this.mB, this), f, d, e);
        c.customDialLaunchCallback = (0, g.w)(this.IK, this);
        chrome.cast.initialize(c, (0, g.w)(function() {
            this.ha() ||
                (chrome.cast.addReceiverActionListener(this.B), Kxa(), this.u.subscribe("onlineScreenChange", (0, g.w)(this.lD, this)), this.A = eya(this), chrome.cast.setCustomReceivers(this.A, g.Ia, (0, g.w)(function(k) {
                    this.Xb("Failed to set initial custom receivers: " + g.Kk(k))
                }, this)), this.T("yt-remote-cast2-availability-change", F7(this)), b(!0))
        }, this), (0, g.w)(function(k) {
            this.Xb("Failed to initialize API: " + g.Kk(k));
            b(!1)
        }, this))
    };
    g.h.lO = function(a, b) {
        E7("Setting connected screen ID: " + a + " -> " + b);
        if (this.o) {
            var c = this.o.A;
            if (!a || c && c.id != a) E7("Unsetting old screen status: " + this.o.u.friendlyName), G7(this, null)
        }
        if (a && b) {
            if (!this.o) {
                c = l6(this.u.ge(), a);
                if (!c) {
                    E7("setConnectedScreenStatus: Unknown screen.");
                    return
                }
                var d = dya(this, c);
                d || (E7("setConnectedScreenStatus: Connected receiver not custom..."), d = new chrome.cast.Receiver(c.uuid ? c.uuid : c.id, c.name), d.receiverType = chrome.cast.ReceiverType.CUSTOM, this.A.push(d), chrome.cast.setCustomReceivers(this.A,
                    g.Ia, (0, g.w)(function(e) {
                        this.Xb("Failed to set initial custom receivers: " + g.Kk(e))
                    }, this)));
                E7("setConnectedScreenStatus: new active receiver: " + d.friendlyName);
                G7(this, new C7(this.u, d), !0)
            }
            this.o.Su(b)
        } else E7("setConnectedScreenStatus: no screen.")
    };
    g.h.mO = function(a) {
        this.ha() ? this.Xb("Setting connection data on disposed cast v2") : this.o ? this.o.ek(a) : this.Xb("Setting connection data without a session")
    };
    g.h.lP = function() {
        this.ha() ? this.Xb("Stopping session on disposed cast v2") : this.o ? (this.o.stop(), G7(this, null)) : E7("Stopping non-existing session")
    };
    g.h.requestSession = function() {
        chrome.cast.requestSession((0, g.w)(this.mB, this), (0, g.w)(this.TM, this))
    };
    g.h.Y = function() {
        this.u.unsubscribe("onlineScreenChange", (0, g.w)(this.lD, this));
        window.chrome && chrome.cast && chrome.cast.removeReceiverActionListener(this.B);
        var a = Hxa,
            b = g.Ha("yt.mdx.remote.debug.handlers_");
        g.db(b || [], a);
        g.He(this.o);
        D7.Gb.Y.call(this)
    };
    g.h.Xb = function(a) {
        i7("Controller", a)
    };
    g.h.oB = function(a, b) {
        this.o == a && (b || G7(this, null), this.T("yt-remote-cast2-session-change", b))
    };
    g.h.sM = function(a, b) {
        if (!this.ha())
            if (a) switch (a.friendlyName = chrome.cast.unescape(a.friendlyName), E7("onReceiverAction_ " + a.label + " / " + a.friendlyName + "-- " + b), b) {
                case chrome.cast.ReceiverAction.CAST:
                    if (this.o)
                        if (this.o.u.label != a.label) E7("onReceiverAction_: Stopping active receiver: " + this.o.u.friendlyName), this.o.stop();
                        else {
                            E7("onReceiverAction_: Casting to active receiver.");
                            this.o.A && this.T("yt-remote-cast2-session-change", this.o.A);
                            break
                        }
                    switch (a.receiverType) {
                        case chrome.cast.ReceiverType.CUSTOM:
                            G7(this,
                                new C7(this.u, a));
                            break;
                        case chrome.cast.ReceiverType.DIAL:
                            G7(this, new B7(this.u, a, this.D));
                            break;
                        case chrome.cast.ReceiverType.CAST:
                            G7(this, new A7(this.u, a));
                            break;
                        default:
                            this.Xb("Unknown receiver type: " + a.receiverType)
                    }
                    break;
                case chrome.cast.ReceiverAction.STOP:
                    this.o && this.o.u.label == a.label ? this.o.stop() : this.Xb("Stopping receiver w/o session: " + a.friendlyName)
            } else this.Xb("onReceiverAction_ called without receiver.")
    };
    g.h.IK = function(a) {
        if (this.ha()) return Promise.reject(Error("disposed"));
        var b = a.receiver;
        b.receiverType != chrome.cast.ReceiverType.DIAL && (this.Xb("Not DIAL receiver: " + b.friendlyName), b.receiverType = chrome.cast.ReceiverType.DIAL);
        var c = this.o ? this.o.u : null;
        if (!c || c.label != b.label) return this.Xb("Receiving DIAL launch request for non-clicked DIAL receiver: " + b.friendlyName), Promise.reject(Error("illegal DIAL launch"));
        if (c && c.label == b.label && c.receiverType != chrome.cast.ReceiverType.DIAL) {
            if (this.o.A) return E7("Reselecting dial screen."),
                this.T("yt-remote-cast2-session-change", this.o.A), Promise.resolve(new chrome.cast.DialLaunchResponse(!1));
            this.Xb('Changing CAST intent from "' + c.receiverType + '" to "dial" for ' + b.friendlyName);
            G7(this, new B7(this.u, b, this.D))
        }
        b = this.o;
        b.H = a;
        return b.H.appState == chrome.cast.DialAppState.RUNNING ? new Promise((0, g.w)(b.XF, b, (b.H.extraData || {}).screenId || null)) : new Promise((0, g.w)(b.Ns, b))
    };
    g.h.mB = function(a) {
        if (!this.ha()) {
            E7("New cast session ID: " + a.sessionId);
            var b = a.receiver;
            if (b.receiverType != chrome.cast.ReceiverType.CUSTOM) {
                if (!this.o)
                    if (b.receiverType == chrome.cast.ReceiverType.CAST) E7("Got resumed cast session before resumed mdx connection."), b.friendlyName = chrome.cast.unescape(b.friendlyName), G7(this, new A7(this.u, b), !0);
                    else {
                        this.Xb("Got non-cast session without previous mdx receiver event, or mdx resume.");
                        return
                    }
                var c = this.o.u,
                    d = l6(this.u.ge(), c.label);
                d && g6(d, b.label) &&
                    c.receiverType != chrome.cast.ReceiverType.CAST && b.receiverType == chrome.cast.ReceiverType.CAST && (E7("onSessionEstablished_: manual to cast session change " + b.friendlyName), g.He(this.o), this.o = new A7(this.u, b), this.o.subscribe("sessionScreen", (0, g.w)(this.oB, this, this.o)), this.o.ek(null));
                this.o.Ru(a)
            }
        }
    };
    g.h.kP = function() {
        return this.o ? this.o.mD() : null
    };
    g.h.TM = function(a) {
        this.ha() || (this.Xb("Failed to estabilish a session: " + g.Kk(a)), a.code != chrome.cast.ErrorCode.CANCEL && G7(this, null))
    };
    g.h.wM = function(a) {
        E7("Receiver availability updated: " + a);
        if (!this.ha()) {
            var b = F7(this);
            this.C = a == chrome.cast.ReceiverAvailability.AVAILABLE;
            F7(this) != b && this.T("yt-remote-cast2-availability-change", F7(this))
        }
    };
    g.h.lD = function() {
        this.ha() || (this.A = eya(this), E7("Updating custom receivers: " + g.Kk(this.A)), chrome.cast.setCustomReceivers(this.A, g.Ia, (0, g.w)(function() {
            this.Xb("Failed to set custom receivers.")
        }, this)), this.T("yt-remote-cast2-availability-change", F7(this)))
    };
    D7.prototype.setLaunchParams = D7.prototype.mO;
    D7.prototype.setConnectedScreenStatus = D7.prototype.lO;
    D7.prototype.stopSession = D7.prototype.lP;
    D7.prototype.getCastSession = D7.prototype.kP;
    D7.prototype.requestSession = D7.prototype.requestSession;
    D7.prototype.init = D7.prototype.init;
    D7.prototype.dispose = D7.prototype.dispose;
    var M7 = [];
    g.h = R7.prototype;
    g.h.reset = function(a) {
        this.listId = "";
        this.index = -1;
        this.videoId = "";
        S7(this);
        this.volume = -1;
        this.muted = !1;
        a && (this.index = a.index, this.listId = a.listId, this.videoId = a.videoId, this.playerState = a.playerState, this.volume = a.volume, this.muted = a.muted, this.audioTrackId = a.audioTrackId, this.o = a.trackData, this.Bf = a.hasPrevious, this.hasNext = a.hasNext, this.G = a.playerTime, this.D = a.playerTimeAt, this.C = a.seekableStart, this.u = a.seekableEnd, this.H = a.duration, this.J = a.loadedTime, this.B = a.liveIngestionTime, this.A = !isNaN(this.B))
    };
    g.h.fb = function() {
        return 1 == this.playerState
    };
    g.h.isAdPlaying = function() {
        return 1081 == this.playerState
    };
    g.h.getDuration = function() {
        return this.A ? this.H + T7(this) : this.H
    };
    g.h.clone = function() {
        return new R7(X7(this))
    };
    g.r(Z7, g.N);
    g.h = Z7.prototype;
    g.h.play = function() {
        1 == this.o ? (this.u ? this.u.play(null, g.Ia, e8(this, "play")) : d8(this, "play"), c8(this, 1, V7($7(this))), this.T("remotePlayerChange")) : a8(this, this.play)
    };
    g.h.pause = function() {
        1 == this.o ? (this.u ? this.u.pause(null, g.Ia, e8(this, "pause")) : d8(this, "pause"), c8(this, 2, V7($7(this))), this.T("remotePlayerChange")) : a8(this, this.pause)
    };
    g.h.seekTo = function(a) {
        if (1 == this.o) {
            if (this.u) {
                var b = $7(this),
                    c = new chrome.cast.media.SeekRequest;
                c.currentTime = a;
                b.fb() || 3 == b.playerState ? c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_START : c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_PAUSE;
                this.u.seek(c, g.Ia, e8(this, "seekTo", {
                    newTime: a
                }))
            } else d8(this, "seekTo", {
                newTime: a
            });
            c8(this, 3, a);
            this.T("remotePlayerChange")
        } else a8(this, g.Qa(this.seekTo, a))
    };
    g.h.stop = function() {
        if (1 == this.o) {
            this.u ? this.u.stop(null, g.Ia, e8(this, "stopVideo")) : d8(this, "stopVideo");
            var a = $7(this);
            a.index = -1;
            a.videoId = "";
            S7(a);
            b8(this, a);
            this.T("remotePlayerChange")
        } else a8(this, this.stop)
    };
    g.h.setVolume = function(a, b) {
        if (1 == this.o) {
            var c = $7(this);
            if (this.A) {
                if (c.volume != a) {
                    var d = Math.round(a) / 100;
                    this.A.setReceiverVolumeLevel(d, (0, g.w)(function() {
                        i7("CP", "set receiver volume: " + d)
                    }, this), (0, g.w)(function() {
                        this.Xb("failed to set receiver volume.")
                    }, this))
                }
                c.muted != b && this.A.setReceiverMuted(b, (0, g.w)(function() {
                    i7("CP", "set receiver muted: " + b)
                }, this), (0, g.w)(function() {
                    this.Xb("failed to set receiver muted.")
                }, this))
            } else {
                var e = {
                    volume: a,
                    muted: b
                }; - 1 != c.volume && (e.delta = a - c.volume);
                d8(this, "setVolume", e)
            }
            c.muted = b;
            c.volume = a;
            b8(this, c)
        } else a8(this, g.Qa(this.setVolume, a, b))
    };
    g.h.hD = function(a, b) {
        if (1 == this.o) {
            var c = $7(this),
                d = {
                    videoId: a
                };
            b && (c.o = {
                trackName: b.name,
                languageCode: b.languageCode,
                sourceLanguageCode: b.translationLanguage ? b.translationLanguage.languageCode : "",
                languageName: b.languageName,
                kind: b.kind
            }, d.style = g.Kk(b.style), g.Sb(d, c.o));
            d8(this, "setSubtitlesTrack", d);
            b8(this, c)
        } else a8(this, g.Qa(this.hD, a, b))
    };
    g.h.setAudioTrack = function(a, b) {
        if (1 == this.o) {
            var c = b.getLanguageInfo().getId();
            d8(this, "setAudioTrack", {
                videoId: a,
                audioTrackId: c
            });
            var d = $7(this);
            d.audioTrackId = c;
            b8(this, d)
        } else a8(this, g.Qa(this.setAudioTrack, a, b))
    };
    g.h.playVideo = function(a, b, c, d, e, f, k) {
        var l = $7(this);
        c = c || 0;
        var m = {
            videoId: a,
            currentIndex: c
        };
        W7(l, a, c);
        void 0 !== b && (U7(l, b), m.currentTime = b);
        void 0 !== d && (m.listId = d);
        null != e && (m.playerParams = e);
        null != f && (m.clickTrackingParams = f);
        null != k && (m.locationInfo = g.Kk(k));
        d8(this, "setPlaylist", m);
        d || b8(this, l)
    };
    g.h.Pp = function(a, b) {
        if (1 == this.o) {
            if (a && b) {
                var c = $7(this);
                W7(c, a, b);
                b8(this, c)
            }
            d8(this, "previous")
        } else a8(this, g.Qa(this.Pp, a, b))
    };
    g.h.nextVideo = function(a, b) {
        if (1 == this.o) {
            if (a && b) {
                var c = $7(this);
                W7(c, a, b);
                b8(this, c)
            }
            d8(this, "next")
        } else a8(this, g.Qa(this.nextVideo, a, b))
    };
    g.h.ex = function() {
        1 == this.o ? d8(this, "dismissAutoplay") : a8(this, this.ex)
    };
    g.h.dispose = function() {
        if (3 != this.o) {
            var a = this.o;
            this.o = 3;
            this.T("proxyStateChange", a, this.o)
        }
        g.N.prototype.dispose.call(this)
    };
    g.h.Y = function() {
        rya(this);
        this.B = null;
        this.C.clear();
        Y7(this, null);
        g.N.prototype.Y.call(this)
    };
    g.h.Dv = function(a) {
        if ((a != this.o || 2 == a) && 3 != this.o && 0 != a) {
            var b = this.o;
            this.o = a;
            this.T("proxyStateChange", b, a);
            if (1 == a)
                for (; !this.C.isEmpty();) b = a = this.C, g.ab(b.o) && (b.o = b.u, b.o.reverse(), b.u = []), a.o.pop().apply(this);
            else 3 == a && this.dispose()
        }
    };
    g.h.pM = function(a, b) {
        this.T(a, b)
    };
    g.h.rK = function(a) {
        if (!a) this.zm(null), Y7(this, null);
        else if (this.A.receiver.volume) {
            a = this.A.receiver.volume;
            var b = $7(this),
                c = Math.round(100 * a.level || 0);
            if (b.volume != c || b.muted != a.muted) i7("CP", "Cast volume update: " + a.level + (a.muted ? " muted" : "")), b.volume = c, b.muted = !!a.muted, b8(this, b)
        }
    };
    g.h.zm = function(a) {
        i7("CP", "Cast media: " + !!a);
        this.u && this.u.removeUpdateListener(this.H);
        if (this.u = a) this.u.addUpdateListener(this.H), sya(this), this.T("remotePlayerChange")
    };
    g.h.qK = function(a) {
        a ? (sya(this), this.T("remotePlayerChange")) : this.zm(null)
    };
    g.h.dv = function() {
        d8(this, "sendDebugCommand", {
            debugCommand: "stats4nerds "
        })
    };
    g.h.BK = function() {
        var a = oya();
        a && Y7(this, a)
    };
    g.h.Xb = function(a) {
        i7("CP", a)
    };
    g.r(f8, g.N);
    g.h = f8.prototype;
    g.h.connect = function(a, b) {
        if (b) {
            var c = b.listId,
                d = b.videoId,
                e = b.playerParams,
                f = b.clickTrackingParams,
                k = b.index,
                l = {
                    videoId: d
                },
                m = b.currentTime,
                n = b.locationInfo;
            void 0 !== m && (l.currentTime = 5 >= m ? 0 : m);
            e && (l.playerParams = e);
            n && (l.locationInfo = n);
            f && (l.clickTrackingParams = f);
            c && (l.listId = c);
            void 0 !== k && (l.currentIndex = k);
            c && (this.Xa.listId = c);
            this.Xa.videoId = d;
            this.Xa.index = k || 0;
            this.Xa.state = 3;
            U7(this.Xa, m);
            this.B = "UNSUPPORTED";
            g8("Connecting with setPlaylist and params: " + g.Kk(l));
            this.o.connect({
                method: "setPlaylist",
                params: g.Kk(l)
            }, a, Fwa())
        } else g8("Connecting without params"), this.o.connect({}, a, Fwa());
        uya(this)
    };
    g.h.dispose = function() {
        this.ha() || (this.T("beforeDispose"), h8(this, 3));
        g.N.prototype.dispose.call(this)
    };
    g.h.Y = function() {
        i8(this);
        k8(this);
        j8(this);
        g.Ko(this.G);
        this.G = NaN;
        g.Ko(this.H);
        this.H = NaN;
        this.A = null;
        g.fp(this.S);
        this.S.length = 0;
        this.o.dispose();
        g.N.prototype.Y.call(this);
        this.B = this.D = this.u = this.Xa = this.o = null
    };
    g.h.nF = function() {
        this.Dj(2)
    };
    g.h.vK = function() {
        g8("Channel opened");
        this.N && (this.N = !1, j8(this), this.R = g.Io((0, g.w)(function() {
            g8("Timing out waiting for a screen.");
            this.Dj(1)
        }, this), 15E3));
        Jwa(Exa(this.o), this.U)
    };
    g.h.sK = function() {
        g8("Channel closed");
        isNaN(this.C) ? q6(!0) : q6();
        this.dispose()
    };
    g.h.tK = function(a) {
        q6();
        isNaN(this.Kl()) ? (g8("Channel error: " + a + " without reconnection"), this.dispose()) : (this.N = !0, g8("Channel error: " + a + " with reconnection in " + this.Kl() + " ms"), h8(this, 2))
    };
    g.h.uK = function(a) {
        a.params ? g8("Received: action=" + a.action + ", params=" + g.Kk(a.params)) : g8("Received: action=" + a.action + " {}");
        switch (a.action) {
            case "loungeStatus":
                a = x6(a.params.devices);
                this.u = (0, g.Dc)(a, function(c) {
                    return new e6(c)
                });
                a = !!g.Xa(this.u, function(c) {
                    return "LOUNGE_SCREEN" == c.type
                });
                xya(this, a);
                break;
            case "loungeScreenDisconnected":
                g.eb(this.u, function(c) {
                    return "LOUNGE_SCREEN" == c.type
                });
                xya(this, !1);
                break;
            case "remoteConnected":
                var b = new e6(x6(a.params.device));
                g.Xa(this.u, function(c) {
                    return b ? c.id == b.id : !1
                }) || pwa(this.u, b);
                break;
            case "remoteDisconnected":
                b = new e6(x6(a.params.device));
                g.eb(this.u, function(c) {
                    return b ? c.id == b.id : !1
                });
                break;
            case "gracefulDisconnect":
                break;
            case "playlistModified":
                zya(this, a);
                break;
            case "nowPlaying":
                Bya(this, a);
                break;
            case "onStateChange":
                Aya(this, a);
                break;
            case "onAdStateChange":
                Cya(this, a);
                break;
            case "onVolumeChanged":
                Dya(this, a);
                break;
            case "onSubtitlesTrackChanged":
                yya(this, a);
                break;
            case "nowAutoplaying":
                Eya(this, a);
                break;
            case "autoplayDismissed":
                this.T("autoplayDismissed");
                break;
            case "autoplayUpNext":
                this.D = a.params.videoId || null;
                this.T("autoplayUpNext", this.D);
                break;
            case "onAutoplayModeChanged":
                this.B =
                    a.params.autoplayMode;
                this.T("autoplayModeChange", this.B);
                "DISABLED" == this.B && this.T("autoplayDismissed");
                break;
            case "onHasPreviousNextChanged":
                Fya(this, a);
                break;
            case "requestAssistedSignIn":
                this.T("assistedSignInRequested", a.params.authCode);
                break;
            default:
                g8("Unrecognized action: " + a.action)
        }
    };
    g.h.aO = function() {
        if (this.A) {
            var a = this.A;
            this.A = null;
            this.Xa.videoId != a && l8(this, "getNowPlaying")
        }
    };
    g.h.dF = function() {
        var a = 3;
        this.ha() || (a = 0, isNaN(this.Kl()) ? d7(this.o) && isNaN(this.C) && (a = 1) : a = 2);
        return a
    };
    g.h.Dj = function(a) {
        g8("Disconnecting with " + a);
        i8(this);
        this.T("beforeDisconnect", a);
        1 == a && q6();
        Fxa(this.o, a);
        this.dispose()
    };
    g.h.cF = function() {
        var a = this.Xa;
        this.A && (a = this.Xa.clone(), W7(a, this.A, a.index));
        return X7(a)
    };
    g.h.nO = function(a) {
        var b = new R7(a);
        b.videoId && b.videoId != this.Xa.videoId && (this.A = b.videoId, g.Ko(this.G), this.G = g.Io((0, g.w)(this.aO, this), 5E3));
        var c = [];
        this.Xa.listId == b.listId && this.Xa.videoId == b.videoId && this.Xa.index == b.index || c.push("remoteQueueChange");
        this.Xa.playerState == b.playerState && this.Xa.volume == b.volume && this.Xa.muted == b.muted && V7(this.Xa) == V7(b) && g.Kk(this.Xa.o) == g.Kk(b.o) || c.push("remotePlayerChange");
        this.Xa.reset(a);
        (0, g.x)(c, function(d) {
            this.T(d)
        }, this)
    };
    g.h.Rx = function() {
        var a = this.o.D.id,
            b = g.Xa(this.u, function(c) {
                return "REMOTE_CONTROL" == c.type && c.id != a
            });
        return b ? b.id : ""
    };
    g.h.Kl = function() {
        var a = this.o;
        return a.u.isActive() ? a.u.u - (0, g.B)() : NaN
    };
    g.h.RE = function() {
        return this.B || "UNSUPPORTED"
    };
    g.h.SE = function() {
        return this.D || ""
    };
    g.h.dP = function() {
        if (!isNaN(this.Kl())) {
            var a = this.o.u;
            g.vn(a.o);
            a.start()
        }
    };
    g.h.iO = function(a, b) {
        l8(this, a, b);
        wya(this)
    };
    f8.prototype.subscribe = f8.prototype.subscribe;
    f8.prototype.unsubscribeByKey = f8.prototype.Mh;
    f8.prototype.getProxyState = f8.prototype.dF;
    f8.prototype.disconnect = f8.prototype.Dj;
    f8.prototype.getPlayerContextData = f8.prototype.cF;
    f8.prototype.setPlayerContextData = f8.prototype.nO;
    f8.prototype.getOtherConnectedRemoteId = f8.prototype.Rx;
    f8.prototype.getReconnectTimeout = f8.prototype.Kl;
    f8.prototype.getAutoplayMode = f8.prototype.RE;
    f8.prototype.getAutoplayVideoId = f8.prototype.SE;
    f8.prototype.reconnect = f8.prototype.dP;
    f8.prototype.sendMessage = f8.prototype.iO;
    g.r(m8, m7);
    g.h = m8.prototype;
    g.h.ge = function(a) {
        return this.Bd.$_gs(a)
    };
    g.h.contains = function(a) {
        return !!this.Bd.$_c(a)
    };
    g.h.get = function(a) {
        return this.Bd.$_g(a)
    };
    g.h.start = function() {
        this.Bd.$_st()
    };
    g.h.add = function(a, b, c) {
        this.Bd.$_a(a, b, c)
    };
    g.h.remove = function(a, b, c) {
        this.Bd.$_r(a, b, c)
    };
    g.h.yq = function(a, b, c, d) {
        this.Bd.$_un(a, b, c, d)
    };
    g.h.Y = function() {
        for (var a = 0, b = this.u.length; a < b; ++a) this.Bd.$_ubk(this.u[a]);
        this.u.length = 0;
        this.Bd = null;
        m7.prototype.Y.call(this)
    };
    g.h.hP = function() {
        this.T("screenChange")
    };
    g.h.TL = function() {
        this.T("onlineScreenChange")
    };
    v7.prototype.$_st = v7.prototype.start;
    v7.prototype.$_gspc = v7.prototype.iP;
    v7.prototype.$_gsppc = v7.prototype.kD;
    v7.prototype.$_c = v7.prototype.contains;
    v7.prototype.$_g = v7.prototype.get;
    v7.prototype.$_a = v7.prototype.add;
    v7.prototype.$_un = v7.prototype.yq;
    v7.prototype.$_r = v7.prototype.remove;
    v7.prototype.$_gs = v7.prototype.ge;
    v7.prototype.$_gos = v7.prototype.jD;
    v7.prototype.$_s = v7.prototype.subscribe;
    v7.prototype.$_ubk = v7.prototype.Mh;
    var F8 = null,
        E8 = !1,
        n8 = null,
        o8 = null,
        D8 = null,
        s8 = [];
    g.r(G8, g.Q);
    G8.prototype.B = function(a) {
        Qya(this, a.state)
    };
    g.r(H8, g.z);
    g.h = H8.prototype;
    g.h.Y = function() {
        g.z.prototype.Y.call(this);
        this.o.stop();
        this.u.stop();
        this.G.stop();
        this.R();
        var a = this.Sa;
        a.unsubscribe("proxyStateChange", this.iB, this);
        a.unsubscribe("remotePlayerChange", this.Dm, this);
        a.unsubscribe("remoteQueueChange", this.Lp, this);
        a.unsubscribe("previousNextChange", this.eB, this);
        a.unsubscribe("nowAutoplaying", this.aB, this);
        a.unsubscribe("autoplayDismissed", this.zA, this);
        this.Sa = this.module = null
    };
    g.h.vz = function(a, b) {
        for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
        if (2 != this.Sa.o)
            if (J8(this)) {
                if (!$7(this.Sa).isAdPlaying() || "control_seek" !== a) switch (a) {
                    case "control_toggle_play_pause":
                        $7(this.Sa).fb() ? this.Sa.pause() : this.Sa.play();
                        break;
                    case "control_play":
                        this.Sa.play();
                        break;
                    case "control_pause":
                        this.Sa.pause();
                        break;
                    case "control_seek":
                        this.D.ay(c[0], c[1]);
                        break;
                    case "control_subtitles_set_track":
                        K8(this, c[0]);
                        break;
                    case "control_set_audio_track":
                        this.setAudioTrack(c[0])
                }
            } else switch (a) {
                case "control_toggle_play_pause":
                case "control_play":
                case "control_pause":
                    c =
                        this.K.getCurrentTime();
                    L8(this, 0 === c ? void 0 : c);
                    break;
                case "control_seek":
                    L8(this, c[0]);
                    break;
                case "control_subtitles_set_track":
                    K8(this, c[0]);
                    break;
                case "control_set_audio_track":
                    this.setAudioTrack(c[0])
            }
    };
    g.h.pK = function(a) {
        this.G.jF(a)
    };
    g.h.KO = function(a) {
        this.vz("control_subtitles_set_track", g.Mb(a) ? null : a)
    };
    g.h.wC = function() {
        var a = this.K.getOption("captions", "track");
        g.Mb(a) || K8(this, a)
    };
    g.h.Rb = function(a) {
        this.module.Rb(a, this.K.getVideoData().lengthSeconds)
    };
    g.h.OA = function(a) {
        if (J8(this)) {
            this.Sa.unsubscribe("remotePlayerChange", this.Dm, this);
            var b = Math.round(a.volume);
            a = !!a.muted;
            var c = $7(this.Sa);
            if (b !== c.volume || a !== c.muted) this.Sa.setVolume(b, a), this.H.start();
            this.Sa.subscribe("remotePlayerChange", this.Dm, this)
        }
    };
    g.h.qL = function() {
        g.Mb(this.A) || Sya(this, this.A);
        this.B = !1
    };
    g.h.iB = function(a, b) {
        this.u.stop();
        2 === b && this.vC()
    };
    g.h.Dm = function() {
        if (J8(this)) {
            this.o.stop();
            var a = $7(this.Sa);
            switch (a.playerState) {
                case 1080:
                case 1081:
                case 1084:
                case 1085:
                    this.module.Uc = 1;
                    break;
                case 1082:
                case 1083:
                    this.module.Uc = 0;
                    break;
                default:
                    this.module.Uc = -1
            }
            switch (a.playerState) {
                case 1081:
                case 1:
                    I8(this, new g.xC(8));
                    this.uC();
                    break;
                case 1085:
                case 3:
                    I8(this, new g.xC(9));
                    break;
                case 1083:
                case 0:
                    I8(this, new g.xC(2));
                    this.D.stop();
                    this.Rb(this.K.getVideoData().lengthSeconds);
                    break;
                case 1084:
                    I8(this, new g.xC(4));
                    break;
                case 2:
                    I8(this, new g.xC(4));
                    this.Rb(V7(a));
                    break;
                case -1:
                    I8(this, new g.xC(64));
                    break;
                case -1E3:
                    I8(this, new g.xC(128, {
                        errorCode: "mdx.remoteerror",
                        errorMessage: "Bu video uzaktan oynatma i\u00e7in uygun de\u011fil."
                    }))
            }
            a = $7(this.Sa).o;
            var b = this.A;
            (a || b ? a && b && a.trackName == b.trackName && a.languageCode == b.languageCode && a.languageName == b.languageName && a.kind == b.kind : 1) || (this.A = a, Sya(this, a));
            a = $7(this.Sa); - 1 === a.volume || Math.round(this.K.getVolume()) === a.volume && this.K.isMuted() === a.muted || this.H.isActive() || this.VC()
        } else Rya(this)
    };
    g.h.eB = function() {
        this.K.T("mdxpreviousnextchange")
    };
    g.h.Lp = function() {
        J8(this) || Rya(this)
    };
    g.h.aB = function(a) {
        isNaN(a) || this.K.T("mdxnowautoplaying", a)
    };
    g.h.zA = function() {
        this.K.T("mdxautoplaycanceled")
    };
    g.h.setAudioTrack = function(a) {
        J8(this) && this.Sa.setAudioTrack(this.K.getVideoData(1).videoId, a)
    };
    g.h.seekTo = function(a, b) {
        -1 === $7(this.Sa).playerState ? L8(this, a) : b && this.Sa.seekTo(a)
    };
    g.h.VC = function() {
        if (J8(this)) {
            var a = $7(this.Sa);
            this.events.eb(this.J);
            a.muted ? this.K.mute() : this.K.unMute();
            this.K.setVolume(a.volume);
            this.J = this.events.M(this.K, "onVolumeChange", this.OA)
        }
    };
    g.h.uC = function() {
        this.o.stop();
        if (!this.Sa.ha()) {
            var a = $7(this.Sa);
            a.fb() && I8(this, new g.xC(8));
            this.Rb(V7(a));
            this.o.start()
        }
    };
    g.h.vC = function() {
        this.u.stop();
        this.o.stop();
        var a = this.Sa.B.getReconnectTimeout();
        2 == this.Sa.o && !isNaN(a) && this.u.start()
    };
    g.r(M8, g.Q);
    M8.prototype.Tb = function() {
        this.u.show()
    };
    M8.prototype.A = function() {
        g.jO("https://support.google.com/youtube/answer/7640706")
    };
    M8.prototype.B = function() {
        d6("mdx-manual-pairing-popup-ok");
        this.u.hide()
    };
    g.r(N8, g.Q);
    N8.prototype.Tb = function() {
        this.u.show()
    };
    N8.prototype.A = function() {
        d6("mdx-privacy-popup-cancel");
        this.u.hide()
    };
    N8.prototype.B = function() {
        d6("mdx-privacy-popup-confirm");
        this.u.hide()
    };
    g.r(O8, g.PN);
    O8.prototype.D = function() {
        var a = this.K.getOption("remote", "receivers");
        a && 1 < a.length && !this.K.getOption("remote", "quickCast") ? (this.Vh = g.vb(a, this.A, this), g.RN(this, (0, g.Dc)(a, this.A)), a = this.K.getOption("remote", "currentReceiver"), this.Eb(this.A(a)), this.enable(!0)) : this.enable(!1)
    };
    O8.prototype.A = function(a) {
        return a.key
    };
    O8.prototype.ff = function(a) {
        return "cast-selector-receiver" === a ? "Yay\u0131nla..." : this.Vh[a].name
    };
    O8.prototype.ld = function(a) {
        g.PN.prototype.ld.call(this, a);
        this.K.setOption("remote", "currentReceiver", this.Vh[a]);
        this.u.kb()
    };
    g.r(P8, g.BL);
    g.h = P8.prototype;
    g.h.create = function() {
        Kya(g.Hy(this.player.O()));
        this.subscriptions.push(g.Po("yt-remote-before-disconnect", this.mK, this));
        this.subscriptions.push(g.Po("yt-remote-connection-change", this.xM, this));
        this.subscriptions.push(g.Po("yt-remote-receiver-availability-change", this.gB, this));
        this.subscriptions.push(g.Po("yt-remote-auto-connect", this.vM, this));
        this.subscriptions.push(g.Po("yt-remote-receiver-resumed", this.uM, this));
        this.subscriptions.push(g.Po("mdx-privacy-popup-confirm", this.ON, this));
        this.subscriptions.push(g.Po("mdx-privacy-popup-cancel",
            this.NN, this));
        this.subscriptions.push(g.Po("mdx-manual-pairing-popup-ok", this.rG, this));
        this.gB()
    };
    g.h.load = function() {
        this.player.cancelPlayback();
        g.BL.prototype.load.call(this);
        this.ae = new H8(this, this.player, this.Sa);
        var a = (a = Pya()) ? a.currentTime : 0;
        var b = C8() ? new Z7(x8(), void 0) : null;
        0 == a && b && (a = V7($7(b)));
        0 !== a && this.Rb(a);
        Tya(this, this.Cc, this.Cc);
        g.XS(this.player.app, 6)
    };
    g.h.unload = function() {
        this.player.T("mdxautoplaycanceled");
        this.fh = this.cf;
        g.Ie(this.ae, this.Sa);
        this.Sa = this.ae = null;
        g.BL.prototype.unload.call(this);
        g.XS(this.player.app, 5);
        Q8(this)
    };
    g.h.Y = function() {
        g.Qo(this.subscriptions);
        g.BL.prototype.Y.call(this)
    };
    g.h.Mf = function(a, b) {
        for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
        this.loaded && this.ae.vz.apply(this.ae, [a].concat(g.la(c)))
    };
    g.h.getAdState = function() {
        return this.Uc
    };
    g.h.fF = function() {
        return this.loaded ? this.ae.suggestion : null
    };
    g.h.Bf = function() {
        return this.Sa ? $7(this.Sa).Bf : !1
    };
    g.h.hasNext = function() {
        return this.Sa ? $7(this.Sa).hasNext : !1
    };
    g.h.Rb = function(a, b) {
        this.Ky = a || 0;
        this.player.T("progresssync", a, b)
    };
    g.h.getCurrentTime = function() {
        return this.Ky
    };
    g.h.getProgressState = function() {
        var a = $7(this.Sa),
            b = this.player.getVideoData();
        return {
            allowSeeking: g.O(this.player.O().experiments, "web_player_mdx_allow_seeking_change_killswitch") ? this.player.Tc() : !a.isAdPlaying() && this.player.Tc(),
            clipEnd: b.clipEnd,
            clipStart: b.clipStart,
            current: this.getCurrentTime(),
            displayedStart: -1,
            duration: a.getDuration(),
            ingestionTime: a.A ? a.B + T7(a) : a.B,
            isAtLiveHead: 1 >= (a.A ? a.u + T7(a) : a.u) - this.getCurrentTime(),
            loaded: a.J,
            seekableEnd: a.A ? a.u + T7(a) : a.u,
            seekableStart: 0 < a.C ? a.C +
                T7(a) : a.C
        }
    };
    g.h.nextVideo = function() {
        this.Sa && this.Sa.nextVideo()
    };
    g.h.Pp = function() {
        this.Sa && this.Sa.Pp()
    };
    g.h.mK = function(a) {
        1 === a && (this.vu = this.Sa ? $7(this.Sa) : null)
    };
    g.h.xM = function() {
        var a = C8() ? new Z7(x8(), void 0) : null;
        if (a) {
            var b = this.fh;
            this.loaded && this.unload();
            this.Sa = a;
            this.vu = null;
            b.key !== this.cf.key && (this.fh = b, this.load())
        } else g.He(this.Sa), this.Sa = null, this.loaded && (this.unload(), (a = this.vu) && a.videoId === this.player.getVideoData().videoId && this.player.cueVideoById(a.videoId, V7(a)));
        this.player.T("videodatachange", "newdata", this.player.getVideoData(), 3)
    };
    g.h.gB = function() {
        this.Vh = [this.cf].concat(Mya());
        var a = y8() || this.cf;
        R8(this, a);
        this.player.sa("onMdxReceiversChange")
    };
    g.h.vM = function() {
        var a = y8();
        R8(this, a)
    };
    g.h.uM = function() {
        this.fh = y8()
    };
    g.h.ON = function() {
        this.Em = !0;
        Q8(this);
        E8 = !1;
        F8 && A8(F8, 1);
        F8 = null
    };
    g.h.NN = function() {
        this.Em = !1;
        Q8(this);
        R8(this, this.cf);
        this.fh = this.cf;
        E8 = !1;
        F8 = null;
        this.player.playVideo()
    };
    g.h.rG = function() {
        this.So = !0;
        Q8(this);
        g.qs("yt-remote-manual-pairing-warning-shown", !0, 2592E3);
        E8 = !1;
        F8 && A8(F8, 1);
        F8 = null
    };
    g.h.Rc = function(a, b) {
        switch (a) {
            case "casting":
                return this.loaded;
            case "receivers":
                return this.Vh;
            case "currentReceiver":
                return b && ("cast-selector-receiver" === b.key ? P7() : R8(this, b)), this.loaded ? this.fh : this.cf;
            case "quickCast":
                return 2 === this.Vh.length && "cast-selector-receiver" === this.Vh[1].key ? (b && P7(), !0) : !1
        }
    };
    g.h.dv = function() {
        this.Sa.dv()
    };
    g.h.Uf = function() {
        return !1
    };
    g.h.getOptions = function() {
        return ["casting", "receivers", "currentReceiver", "quickCast"]
    };
    g.QL.remote = P8;
})(_yt_player);